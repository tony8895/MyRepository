﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eDDA
{
    public class ToCitiData: EventArgs
    {
        public int index { get; set; }
        public int recordID { get; set; }
        public string fileName { get; set; }
        public string amount { get; set; }
        public string clientCode { get; set; }
        public string clientReference { get; set; }
        public string payAmount { get; set; }
        public string payerName { get; set; }
        public string valueDate { get; set; }

    }
}
