﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eDDA
{
    public class FileList: EventArgs
    {
        public string fileName { get; set; }

        public string filePath { get; set; }
    }
}
