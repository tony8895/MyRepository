﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace eDDA
{
    public partial class EditRecordForm : Form
    {
        private ToCitiData toCitiData;
        public event EventHandler<ToCitiData> EditFmSubmitted;

        public EditRecordForm(ToCitiData toCitiData)
        {
            InitializeComponent();
            this.toCitiData = toCitiData;
        }

        private void InputDDAForm_Load(object sender, EventArgs e)
        {
            txtFileName.Text = toCitiData.fileName;
            txtAmount.Text = toCitiData.amount;
            txtClientCode.Text = toCitiData.clientCode;
            txtClientRef.Text = toCitiData.clientReference;
            txtPayAmount.Text = toCitiData.payAmount;
            txtPayerName.Text = toCitiData.payerName;
            txtValueDate.Text = toCitiData.valueDate;

            txtAmount.Focus();
        }

        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            decimal amount;
            DateTime valueDate;

            if (!decimal.TryParse(txtAmount.Text.Trim(), out amount))
            {
                MessageBox.Show("Amount must be in number!");
                return;
            }

            if (!DateTime.TryParse(txtValueDate.Text.Trim(), out valueDate))
            {
                MessageBox.Show("Value Date is invalid!");
                return;
            };

            ToCitiData submitData = new ToCitiData()
            {
                index = toCitiData.index,
                fileName = txtFileName.Text.Trim(),
                amount = txtAmount.Text.Trim(),
                clientCode = txtClientCode.Text.Trim(),
                clientReference = txtClientRef.Text.Trim(),
                payAmount = txtPayAmount.Text.Trim(),
                payerName = txtPayerName.Text.Trim(),
                valueDate = txtValueDate.Text.Trim()
            };

            if (EditFmSubmitted != null)
            {
                EditFmSubmitted(this, submitData);
            }

            this.Close();
        }
    }
}
