﻿namespace eDDA
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripLblUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.tabControlMain = new System.Windows.Forms.TabControl();
            this.tabPageConfig = new System.Windows.Forms.TabPage();
            this.tabControlConfig = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDDPInputPiys = new System.Windows.Forms.TextBox();
            this.lblCfDDPInputPisysFile = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDDPInputHiTrust = new System.Windows.Forms.TextBox();
            this.lblCfDDPInputHitrustFile = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDDPInputESPP = new System.Windows.Forms.TextBox();
            this.lblCfDDPInputEsppFile = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDDPInputXML = new System.Windows.Forms.TextBox();
            this.lblCfDDPInputXmlFile = new System.Windows.Forms.Label();
            this.btnDDPInputSave = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDDPOutputPiys = new System.Windows.Forms.TextBox();
            this.lblCfDDPOutputPisysFile = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtDDPOutputHiTrust = new System.Windows.Forms.TextBox();
            this.lblCfDDPOutputHitrustFile = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtDDPOutputESPP = new System.Windows.Forms.TextBox();
            this.lblCfDDPOutputEsppFile = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtDDPOutputXML = new System.Windows.Forms.TextBox();
            this.lblCfDDPOutputXmlFile = new System.Windows.Forms.Label();
            this.btnDDPOutputSave = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label17 = new System.Windows.Forms.Label();
            this.txtDDAInputPiys = new System.Windows.Forms.TextBox();
            this.lblCfDDAInputPisysFile = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtDDAInputHiTrust = new System.Windows.Forms.TextBox();
            this.lblCfDDAInputHitrustFile = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtDDAInputESPP = new System.Windows.Forms.TextBox();
            this.lblCfDDAInputEsppFile = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtDDAInputXML = new System.Windows.Forms.TextBox();
            this.lblCfDDAInputXmlFile = new System.Windows.Forms.Label();
            this.btnDDAInputSave = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label25 = new System.Windows.Forms.Label();
            this.txtDDAOutputPiys = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtDDAOutputHiTrust = new System.Windows.Forms.TextBox();
            this.lblCfDDAOutputHitrustFile = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtDDAOutputESPP = new System.Windows.Forms.TextBox();
            this.lblCfDDAOutputEsppFile = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.txtDDAOutputXML = new System.Windows.Forms.TextBox();
            this.lblCfDDAOutputXmlFile = new System.Windows.Forms.Label();
            this.btnDDAOutputSave = new System.Windows.Forms.Button();
            this.lblCfDDAOutputPisysFile = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCfDDPRejRptEmailHm = new System.Windows.Forms.TextBox();
            this.txtCfDDPRejRptHm = new System.Windows.Forms.TextBox();
            this.txtCfDDPRejRptEmail = new System.Windows.Forms.TextBox();
            this.lblCfDDPRejRpt = new System.Windows.Forms.Label();
            this.lblCfDDPRejRptEmail = new System.Windows.Forms.Label();
            this.lblCfDDPRejRptHm = new System.Windows.Forms.Label();
            this.lblCfDDPRejRptEmailHm = new System.Windows.Forms.Label();
            this.txtCFDDPRejRpt = new System.Windows.Forms.TextBox();
            this.btnDDPRptSave = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtCFDDPSbmRpt = new System.Windows.Forms.TextBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.btnCfSaveDDASetup = new System.Windows.Forms.Button();
            this.txtClientCodePisysCobrd = new System.Windows.Forms.TextBox();
            this.txtClientCodePisysCore = new System.Windows.Forms.TextBox();
            this.txtClientCodeHitrust = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtClientCodeESPP = new System.Windows.Forms.TextBox();
            this.tabPageFromCiti = new System.Windows.Forms.TabPage();
            this.btnResetFromCiti = new System.Windows.Forms.Button();
            this.tabControlFromCiti = new System.Windows.Forms.TabControl();
            this.tabPageFromCitiStep1 = new System.Windows.Forms.TabPage();
            this.dataGridViewFrmCitiFileList = new System.Windows.Forms.DataGridView();
            this.fileNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.filePathDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FromCitiDeleteFile = new System.Windows.Forms.DataGridViewButtonColumn();
            this.fileListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnFromCitiStep1Next = new System.Windows.Forms.Button();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.dateFromCitiFromDt = new System.Windows.Forms.DateTimePicker();
            this.btnImportXml = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioBtnDDPFromCiti = new System.Windows.Forms.RadioButton();
            this.radioBtnDDAFromCiti = new System.Windows.Forms.RadioButton();
            this.label34 = new System.Windows.Forms.Label();
            this.lblToDateFromCiti = new System.Windows.Forms.Label();
            this.dateFromCitiToDt = new System.Windows.Forms.DateTimePicker();
            this.tabPageFromCitiStep2 = new System.Windows.Forms.TabPage();
            this.btnFromCitiStep2Back = new System.Windows.Forms.Button();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.label36 = new System.Windows.Forms.Label();
            this.btnFromCitiConvertTxt = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.btnFromCitiGenRpt = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.btnFromCitiSendeMail = new System.Windows.Forms.Button();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.tabPageToCiti = new System.Windows.Forms.TabPage();
            this.btnResetToCiti = new System.Windows.Forms.Button();
            this.tabControlToCiti = new System.Windows.Forms.TabControl();
            this.tabPageToCitiStep1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.labelValidateMsg = new System.Windows.Forms.Label();
            this.textBoxValidateMsg = new System.Windows.Forms.TextBox();
            this.btnToCitiStep1Next = new System.Windows.Forms.Button();
            this.dataGridViewToCitiFileList = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toCitiFileDelete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.dateToCitiFromDt = new System.Windows.Forms.DateTimePicker();
            this.label49 = new System.Windows.Forms.Label();
            this.buttonImport = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioBtnDDPToCiti = new System.Windows.Forms.RadioButton();
            this.radioBtnDDAToCiti = new System.Windows.Forms.RadioButton();
            this.label56 = new System.Windows.Forms.Label();
            this.dateToCitiToDt = new System.Windows.Forms.DateTimePicker();
            this.tabPageToCitiStep2 = new System.Windows.Forms.TabPage();
            this.buttonCombine = new System.Windows.Forms.Button();
            this.btnToCitiStep2Back = new System.Windows.Forms.Button();
            this.btnToCitiStep2Next = new System.Windows.Forms.Button();
            this.dataGridViewToCitiData = new System.Windows.Forms.DataGridView();
            this.recordID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fileNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientReferenceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.payAmountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.payerNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valueDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ToCitiDataEdit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ToCitiDataDelete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ToCitiDataCombine = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.toCitiDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPageToCitiStep3 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.label50 = new System.Windows.Forms.Label();
            this.btnConvert = new System.Windows.Forms.Button();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.btnToCitiStep3Back = new System.Windows.Forms.Button();
            this.statusStrip1.SuspendLayout();
            this.tabControlMain.SuspendLayout();
            this.tabPageConfig.SuspendLayout();
            this.tabControlConfig.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tabPageFromCiti.SuspendLayout();
            this.tabControlFromCiti.SuspendLayout();
            this.tabPageFromCitiStep1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFrmCitiFileList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileListBindingSource)).BeginInit();
            this.tableLayoutPanel6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPageFromCitiStep2.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tabPageToCiti.SuspendLayout();
            this.tabControlToCiti.SuspendLayout();
            this.tabPageToCitiStep1.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewToCitiFileList)).BeginInit();
            this.tableLayoutPanel9.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPageToCitiStep2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewToCitiData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.toCitiDataBindingSource)).BeginInit();
            this.tabPageToCitiStep3.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLblUser});
            this.statusStrip1.Location = new System.Drawing.Point(0, 785);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1192, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripLblUser
            // 
            this.toolStripLblUser.Name = "toolStripLblUser";
            this.toolStripLblUser.Size = new System.Drawing.Size(29, 17);
            this.toolStripLblUser.Text = "User";
            // 
            // tabControlMain
            // 
            this.tabControlMain.Controls.Add(this.tabPageConfig);
            this.tabControlMain.Controls.Add(this.tabPageFromCiti);
            this.tabControlMain.Controls.Add(this.tabPageToCiti);
            this.tabControlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabControlMain.ItemSize = new System.Drawing.Size(60, 30);
            this.tabControlMain.Location = new System.Drawing.Point(0, 0);
            this.tabControlMain.Margin = new System.Windows.Forms.Padding(0);
            this.tabControlMain.Name = "tabControlMain";
            this.tabControlMain.Padding = new System.Drawing.Point(20, 3);
            this.tabControlMain.SelectedIndex = 0;
            this.tabControlMain.Size = new System.Drawing.Size(1192, 785);
            this.tabControlMain.TabIndex = 1;
            // 
            // tabPageConfig
            // 
            this.tabPageConfig.Controls.Add(this.tabControlConfig);
            this.tabPageConfig.Location = new System.Drawing.Point(4, 34);
            this.tabPageConfig.Margin = new System.Windows.Forms.Padding(0);
            this.tabPageConfig.Name = "tabPageConfig";
            this.tabPageConfig.Size = new System.Drawing.Size(1184, 747);
            this.tabPageConfig.TabIndex = 0;
            this.tabPageConfig.Text = "Config";
            this.tabPageConfig.UseVisualStyleBackColor = true;
            // 
            // tabControlConfig
            // 
            this.tabControlConfig.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControlConfig.Controls.Add(this.tabPage1);
            this.tabControlConfig.Controls.Add(this.tabPage2);
            this.tabControlConfig.Controls.Add(this.tabPage3);
            this.tabControlConfig.Controls.Add(this.tabPage4);
            this.tabControlConfig.Controls.Add(this.tabPage5);
            this.tabControlConfig.Controls.Add(this.tabPage6);
            this.tabControlConfig.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tabControlConfig.ItemSize = new System.Drawing.Size(30, 120);
            this.tabControlConfig.Location = new System.Drawing.Point(33, 42);
            this.tabControlConfig.Multiline = true;
            this.tabControlConfig.Name = "tabControlConfig";
            this.tabControlConfig.SelectedIndex = 0;
            this.tabControlConfig.Size = new System.Drawing.Size(1121, 544);
            this.tabControlConfig.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControlConfig.TabIndex = 0;
            this.tabControlConfig.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabControlConfig_DrawItem);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Location = new System.Drawing.Point(124, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(993, 536);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "DDP Input";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtDDPInputPiys, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblCfDDPInputPisysFile, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtDDPInputHiTrust, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblCfDDPInputHitrustFile, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtDDPInputESPP, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblCfDDPInputEsppFile, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.txtDDPInputXML, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.lblCfDDPInputXmlFile, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.btnDDPInputSave, 1, 12);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(44, 17);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 13;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(789, 520);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 5);
            this.label1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Pisys";
            // 
            // txtDDPInputPiys
            // 
            this.txtDDPInputPiys.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDPInputPiys.Location = new System.Drawing.Point(133, 3);
            this.txtDDPInputPiys.Name = "txtDDPInputPiys";
            this.txtDDPInputPiys.Size = new System.Drawing.Size(620, 23);
            this.txtDDPInputPiys.TabIndex = 1;
            // 
            // lblCfDDPInputPisysFile
            // 
            this.lblCfDDPInputPisysFile.AutoSize = true;
            this.lblCfDDPInputPisysFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDPInputPisysFile.Location = new System.Drawing.Point(133, 38);
            this.lblCfDDPInputPisysFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDPInputPisysFile.Name = "lblCfDDPInputPisysFile";
            this.lblCfDDPInputPisysFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDPInputPisysFile.TabIndex = 2;
            this.lblCfDDPInputPisysFile.Text = "[FileList]";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 101);
            this.label3.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "HiTrust";
            // 
            // txtDDPInputHiTrust
            // 
            this.txtDDPInputHiTrust.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDPInputHiTrust.Location = new System.Drawing.Point(133, 99);
            this.txtDDPInputHiTrust.Name = "txtDDPInputHiTrust";
            this.txtDDPInputHiTrust.Size = new System.Drawing.Size(620, 23);
            this.txtDDPInputHiTrust.TabIndex = 4;
            // 
            // lblCfDDPInputHitrustFile
            // 
            this.lblCfDDPInputHitrustFile.AutoSize = true;
            this.lblCfDDPInputHitrustFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDPInputHitrustFile.Location = new System.Drawing.Point(133, 134);
            this.lblCfDDPInputHitrustFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDPInputHitrustFile.Name = "lblCfDDPInputHitrustFile";
            this.lblCfDDPInputHitrustFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDPInputHitrustFile.TabIndex = 5;
            this.lblCfDDPInputHitrustFile.Text = "[FileList]";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 197);
            this.label7.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "ESPP";
            // 
            // txtDDPInputESPP
            // 
            this.txtDDPInputESPP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDPInputESPP.Location = new System.Drawing.Point(133, 195);
            this.txtDDPInputESPP.Name = "txtDDPInputESPP";
            this.txtDDPInputESPP.Size = new System.Drawing.Size(620, 23);
            this.txtDDPInputESPP.TabIndex = 7;
            // 
            // lblCfDDPInputEsppFile
            // 
            this.lblCfDDPInputEsppFile.AutoSize = true;
            this.lblCfDDPInputEsppFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDPInputEsppFile.Location = new System.Drawing.Point(133, 230);
            this.lblCfDDPInputEsppFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDPInputEsppFile.Name = "lblCfDDPInputEsppFile";
            this.lblCfDDPInputEsppFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDPInputEsppFile.TabIndex = 8;
            this.lblCfDDPInputEsppFile.Text = "[FileList]";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 293);
            this.label9.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "XML From Citi";
            // 
            // txtDDPInputXML
            // 
            this.txtDDPInputXML.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDPInputXML.Location = new System.Drawing.Point(133, 291);
            this.txtDDPInputXML.Name = "txtDDPInputXML";
            this.txtDDPInputXML.Size = new System.Drawing.Size(620, 23);
            this.txtDDPInputXML.TabIndex = 10;
            // 
            // lblCfDDPInputXmlFile
            // 
            this.lblCfDDPInputXmlFile.AutoSize = true;
            this.lblCfDDPInputXmlFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDPInputXmlFile.Location = new System.Drawing.Point(133, 326);
            this.lblCfDDPInputXmlFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDPInputXmlFile.Name = "lblCfDDPInputXmlFile";
            this.lblCfDDPInputXmlFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDPInputXmlFile.TabIndex = 11;
            this.lblCfDDPInputXmlFile.Text = "[FileList]";
            // 
            // btnDDPInputSave
            // 
            this.btnDDPInputSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDDPInputSave.Location = new System.Drawing.Point(672, 387);
            this.btnDDPInputSave.Name = "btnDDPInputSave";
            this.btnDDPInputSave.Size = new System.Drawing.Size(114, 37);
            this.btnDDPInputSave.TabIndex = 12;
            this.btnDDPInputSave.Text = "SAVE";
            this.btnDDPInputSave.UseVisualStyleBackColor = true;
            this.btnDDPInputSave.Click += new System.EventHandler(this.btnDDPInputSave_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tableLayoutPanel2);
            this.tabPage2.Location = new System.Drawing.Point(124, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(993, 536);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "DDP Output";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtDDPOutputPiys, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.lblCfDDPOutputPisysFile, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label11, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.txtDDPOutputHiTrust, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.lblCfDDPOutputHitrustFile, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.label13, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.txtDDPOutputESPP, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.lblCfDDPOutputEsppFile, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.label15, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.txtDDPOutputXML, 1, 9);
            this.tableLayoutPanel2.Controls.Add(this.lblCfDDPOutputXmlFile, 1, 10);
            this.tableLayoutPanel2.Controls.Add(this.btnDDPOutputSave, 1, 12);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(44, 17);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 13;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(789, 520);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 5);
            this.label5.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 17);
            this.label5.TabIndex = 0;
            this.label5.Text = "Pisys";
            // 
            // txtDDPOutputPiys
            // 
            this.txtDDPOutputPiys.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDPOutputPiys.Location = new System.Drawing.Point(133, 3);
            this.txtDDPOutputPiys.Name = "txtDDPOutputPiys";
            this.txtDDPOutputPiys.Size = new System.Drawing.Size(620, 23);
            this.txtDDPOutputPiys.TabIndex = 1;
            // 
            // lblCfDDPOutputPisysFile
            // 
            this.lblCfDDPOutputPisysFile.AutoSize = true;
            this.lblCfDDPOutputPisysFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDPOutputPisysFile.Location = new System.Drawing.Point(133, 38);
            this.lblCfDDPOutputPisysFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDPOutputPisysFile.Name = "lblCfDDPOutputPisysFile";
            this.lblCfDDPOutputPisysFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDPOutputPisysFile.TabIndex = 2;
            this.lblCfDDPOutputPisysFile.Text = "[FileList]";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 101);
            this.label11.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 17);
            this.label11.TabIndex = 3;
            this.label11.Text = "HiTrust";
            // 
            // txtDDPOutputHiTrust
            // 
            this.txtDDPOutputHiTrust.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDPOutputHiTrust.Location = new System.Drawing.Point(133, 99);
            this.txtDDPOutputHiTrust.Name = "txtDDPOutputHiTrust";
            this.txtDDPOutputHiTrust.Size = new System.Drawing.Size(620, 23);
            this.txtDDPOutputHiTrust.TabIndex = 4;
            // 
            // lblCfDDPOutputHitrustFile
            // 
            this.lblCfDDPOutputHitrustFile.AutoSize = true;
            this.lblCfDDPOutputHitrustFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDPOutputHitrustFile.Location = new System.Drawing.Point(133, 134);
            this.lblCfDDPOutputHitrustFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDPOutputHitrustFile.Name = "lblCfDDPOutputHitrustFile";
            this.lblCfDDPOutputHitrustFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDPOutputHitrustFile.TabIndex = 5;
            this.lblCfDDPOutputHitrustFile.Text = "[FileList]";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 197);
            this.label13.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 17);
            this.label13.TabIndex = 6;
            this.label13.Text = "ESPP";
            // 
            // txtDDPOutputESPP
            // 
            this.txtDDPOutputESPP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDPOutputESPP.Location = new System.Drawing.Point(133, 195);
            this.txtDDPOutputESPP.Name = "txtDDPOutputESPP";
            this.txtDDPOutputESPP.Size = new System.Drawing.Size(620, 23);
            this.txtDDPOutputESPP.TabIndex = 7;
            // 
            // lblCfDDPOutputEsppFile
            // 
            this.lblCfDDPOutputEsppFile.AutoSize = true;
            this.lblCfDDPOutputEsppFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDPOutputEsppFile.Location = new System.Drawing.Point(133, 230);
            this.lblCfDDPOutputEsppFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDPOutputEsppFile.Name = "lblCfDDPOutputEsppFile";
            this.lblCfDDPOutputEsppFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDPOutputEsppFile.TabIndex = 8;
            this.lblCfDDPOutputEsppFile.Text = "[FileList]";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 293);
            this.label15.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 17);
            this.label15.TabIndex = 9;
            this.label15.Text = "XML To Citi";
            // 
            // txtDDPOutputXML
            // 
            this.txtDDPOutputXML.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDPOutputXML.Location = new System.Drawing.Point(133, 291);
            this.txtDDPOutputXML.Name = "txtDDPOutputXML";
            this.txtDDPOutputXML.Size = new System.Drawing.Size(620, 23);
            this.txtDDPOutputXML.TabIndex = 10;
            // 
            // lblCfDDPOutputXmlFile
            // 
            this.lblCfDDPOutputXmlFile.AutoSize = true;
            this.lblCfDDPOutputXmlFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDPOutputXmlFile.Location = new System.Drawing.Point(133, 326);
            this.lblCfDDPOutputXmlFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDPOutputXmlFile.Name = "lblCfDDPOutputXmlFile";
            this.lblCfDDPOutputXmlFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDPOutputXmlFile.TabIndex = 11;
            this.lblCfDDPOutputXmlFile.Text = "[FileList]";
            // 
            // btnDDPOutputSave
            // 
            this.btnDDPOutputSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDDPOutputSave.Location = new System.Drawing.Point(672, 387);
            this.btnDDPOutputSave.Name = "btnDDPOutputSave";
            this.btnDDPOutputSave.Size = new System.Drawing.Size(114, 37);
            this.btnDDPOutputSave.TabIndex = 12;
            this.btnDDPOutputSave.Text = "SAVE";
            this.btnDDPOutputSave.UseVisualStyleBackColor = true;
            this.btnDDPOutputSave.Click += new System.EventHandler(this.btnDDPOutputSave_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tableLayoutPanel3);
            this.tabPage3.Location = new System.Drawing.Point(124, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(993, 536);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "DDA Input";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.txtDDAInputPiys, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.lblCfDDAInputPisysFile, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label19, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.txtDDAInputHiTrust, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.lblCfDDAInputHitrustFile, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.label21, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.txtDDAInputESPP, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.lblCfDDAInputEsppFile, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.label23, 0, 9);
            this.tableLayoutPanel3.Controls.Add(this.txtDDAInputXML, 1, 9);
            this.tableLayoutPanel3.Controls.Add(this.lblCfDDAInputXmlFile, 1, 10);
            this.tableLayoutPanel3.Controls.Add(this.btnDDAInputSave, 1, 12);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(44, 17);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 13;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(789, 520);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 5);
            this.label17.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(46, 17);
            this.label17.TabIndex = 0;
            this.label17.Text = "Pisys";
            // 
            // txtDDAInputPiys
            // 
            this.txtDDAInputPiys.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDAInputPiys.Location = new System.Drawing.Point(133, 3);
            this.txtDDAInputPiys.Name = "txtDDAInputPiys";
            this.txtDDAInputPiys.Size = new System.Drawing.Size(620, 23);
            this.txtDDAInputPiys.TabIndex = 1;
            // 
            // lblCfDDAInputPisysFile
            // 
            this.lblCfDDAInputPisysFile.AutoSize = true;
            this.lblCfDDAInputPisysFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDAInputPisysFile.Location = new System.Drawing.Point(133, 38);
            this.lblCfDDAInputPisysFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDAInputPisysFile.Name = "lblCfDDAInputPisysFile";
            this.lblCfDDAInputPisysFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDAInputPisysFile.TabIndex = 2;
            this.lblCfDDAInputPisysFile.Text = "[FileList]";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(3, 101);
            this.label19.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 17);
            this.label19.TabIndex = 3;
            this.label19.Text = "HiTrust";
            // 
            // txtDDAInputHiTrust
            // 
            this.txtDDAInputHiTrust.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDAInputHiTrust.Location = new System.Drawing.Point(133, 99);
            this.txtDDAInputHiTrust.Name = "txtDDAInputHiTrust";
            this.txtDDAInputHiTrust.Size = new System.Drawing.Size(620, 23);
            this.txtDDAInputHiTrust.TabIndex = 4;
            // 
            // lblCfDDAInputHitrustFile
            // 
            this.lblCfDDAInputHitrustFile.AutoSize = true;
            this.lblCfDDAInputHitrustFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDAInputHitrustFile.Location = new System.Drawing.Point(133, 134);
            this.lblCfDDAInputHitrustFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDAInputHitrustFile.Name = "lblCfDDAInputHitrustFile";
            this.lblCfDDAInputHitrustFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDAInputHitrustFile.TabIndex = 5;
            this.lblCfDDAInputHitrustFile.Text = "[FileList]";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(3, 197);
            this.label21.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(48, 17);
            this.label21.TabIndex = 6;
            this.label21.Text = "ESPP";
            // 
            // txtDDAInputESPP
            // 
            this.txtDDAInputESPP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDAInputESPP.Location = new System.Drawing.Point(133, 195);
            this.txtDDAInputESPP.Name = "txtDDAInputESPP";
            this.txtDDAInputESPP.Size = new System.Drawing.Size(620, 23);
            this.txtDDAInputESPP.TabIndex = 7;
            // 
            // lblCfDDAInputEsppFile
            // 
            this.lblCfDDAInputEsppFile.AutoSize = true;
            this.lblCfDDAInputEsppFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDAInputEsppFile.Location = new System.Drawing.Point(133, 230);
            this.lblCfDDAInputEsppFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDAInputEsppFile.Name = "lblCfDDAInputEsppFile";
            this.lblCfDDAInputEsppFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDAInputEsppFile.TabIndex = 8;
            this.lblCfDDAInputEsppFile.Text = "[FileList]";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(3, 293);
            this.label23.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(108, 17);
            this.label23.TabIndex = 9;
            this.label23.Text = "XML From Citi";
            // 
            // txtDDAInputXML
            // 
            this.txtDDAInputXML.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDAInputXML.Location = new System.Drawing.Point(133, 291);
            this.txtDDAInputXML.Name = "txtDDAInputXML";
            this.txtDDAInputXML.Size = new System.Drawing.Size(620, 23);
            this.txtDDAInputXML.TabIndex = 10;
            // 
            // lblCfDDAInputXmlFile
            // 
            this.lblCfDDAInputXmlFile.AutoSize = true;
            this.lblCfDDAInputXmlFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDAInputXmlFile.Location = new System.Drawing.Point(133, 326);
            this.lblCfDDAInputXmlFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDAInputXmlFile.Name = "lblCfDDAInputXmlFile";
            this.lblCfDDAInputXmlFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDAInputXmlFile.TabIndex = 11;
            this.lblCfDDAInputXmlFile.Text = "[FileList]";
            // 
            // btnDDAInputSave
            // 
            this.btnDDAInputSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDDAInputSave.Location = new System.Drawing.Point(672, 387);
            this.btnDDAInputSave.Name = "btnDDAInputSave";
            this.btnDDAInputSave.Size = new System.Drawing.Size(114, 37);
            this.btnDDAInputSave.TabIndex = 12;
            this.btnDDAInputSave.Text = "SAVE";
            this.btnDDAInputSave.UseVisualStyleBackColor = true;
            this.btnDDAInputSave.Click += new System.EventHandler(this.btnDDAInputSave_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.tableLayoutPanel4);
            this.tabPage4.Location = new System.Drawing.Point(124, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(993, 536);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "DDA Output";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.label25, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.txtDDAOutputPiys, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label27, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.txtDDAOutputHiTrust, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.lblCfDDAOutputHitrustFile, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.label29, 0, 6);
            this.tableLayoutPanel4.Controls.Add(this.txtDDAOutputESPP, 1, 6);
            this.tableLayoutPanel4.Controls.Add(this.lblCfDDAOutputEsppFile, 1, 7);
            this.tableLayoutPanel4.Controls.Add(this.label31, 0, 9);
            this.tableLayoutPanel4.Controls.Add(this.txtDDAOutputXML, 1, 9);
            this.tableLayoutPanel4.Controls.Add(this.lblCfDDAOutputXmlFile, 1, 10);
            this.tableLayoutPanel4.Controls.Add(this.btnDDAOutputSave, 1, 12);
            this.tableLayoutPanel4.Controls.Add(this.lblCfDDAOutputPisysFile, 1, 1);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(44, 17);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 13;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(789, 520);
            this.tableLayoutPanel4.TabIndex = 2;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(3, 5);
            this.label25.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(46, 17);
            this.label25.TabIndex = 0;
            this.label25.Text = "Pisys";
            // 
            // txtDDAOutputPiys
            // 
            this.txtDDAOutputPiys.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDAOutputPiys.Location = new System.Drawing.Point(133, 3);
            this.txtDDAOutputPiys.Name = "txtDDAOutputPiys";
            this.txtDDAOutputPiys.Size = new System.Drawing.Size(620, 23);
            this.txtDDAOutputPiys.TabIndex = 1;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(3, 101);
            this.label27.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(61, 17);
            this.label27.TabIndex = 3;
            this.label27.Text = "HiTrust";
            // 
            // txtDDAOutputHiTrust
            // 
            this.txtDDAOutputHiTrust.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDAOutputHiTrust.Location = new System.Drawing.Point(133, 99);
            this.txtDDAOutputHiTrust.Name = "txtDDAOutputHiTrust";
            this.txtDDAOutputHiTrust.Size = new System.Drawing.Size(620, 23);
            this.txtDDAOutputHiTrust.TabIndex = 4;
            // 
            // lblCfDDAOutputHitrustFile
            // 
            this.lblCfDDAOutputHitrustFile.AutoSize = true;
            this.lblCfDDAOutputHitrustFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDAOutputHitrustFile.Location = new System.Drawing.Point(133, 134);
            this.lblCfDDAOutputHitrustFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDAOutputHitrustFile.Name = "lblCfDDAOutputHitrustFile";
            this.lblCfDDAOutputHitrustFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDAOutputHitrustFile.TabIndex = 5;
            this.lblCfDDAOutputHitrustFile.Text = "[FileList]";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(3, 197);
            this.label29.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(48, 17);
            this.label29.TabIndex = 6;
            this.label29.Text = "ESPP";
            // 
            // txtDDAOutputESPP
            // 
            this.txtDDAOutputESPP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDAOutputESPP.Location = new System.Drawing.Point(133, 195);
            this.txtDDAOutputESPP.Name = "txtDDAOutputESPP";
            this.txtDDAOutputESPP.Size = new System.Drawing.Size(620, 23);
            this.txtDDAOutputESPP.TabIndex = 7;
            // 
            // lblCfDDAOutputEsppFile
            // 
            this.lblCfDDAOutputEsppFile.AutoSize = true;
            this.lblCfDDAOutputEsppFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDAOutputEsppFile.Location = new System.Drawing.Point(133, 230);
            this.lblCfDDAOutputEsppFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDAOutputEsppFile.Name = "lblCfDDAOutputEsppFile";
            this.lblCfDDAOutputEsppFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDAOutputEsppFile.TabIndex = 8;
            this.lblCfDDAOutputEsppFile.Text = "[FileList]";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(3, 293);
            this.label31.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(91, 17);
            this.label31.TabIndex = 9;
            this.label31.Text = "XML To Citi";
            // 
            // txtDDAOutputXML
            // 
            this.txtDDAOutputXML.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDDAOutputXML.Location = new System.Drawing.Point(133, 291);
            this.txtDDAOutputXML.Name = "txtDDAOutputXML";
            this.txtDDAOutputXML.Size = new System.Drawing.Size(620, 23);
            this.txtDDAOutputXML.TabIndex = 10;
            // 
            // lblCfDDAOutputXmlFile
            // 
            this.lblCfDDAOutputXmlFile.AutoSize = true;
            this.lblCfDDAOutputXmlFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDAOutputXmlFile.Location = new System.Drawing.Point(133, 326);
            this.lblCfDDAOutputXmlFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDAOutputXmlFile.Name = "lblCfDDAOutputXmlFile";
            this.lblCfDDAOutputXmlFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDAOutputXmlFile.TabIndex = 11;
            this.lblCfDDAOutputXmlFile.Text = "[FileList]";
            // 
            // btnDDAOutputSave
            // 
            this.btnDDAOutputSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDDAOutputSave.Location = new System.Drawing.Point(672, 387);
            this.btnDDAOutputSave.Name = "btnDDAOutputSave";
            this.btnDDAOutputSave.Size = new System.Drawing.Size(114, 37);
            this.btnDDAOutputSave.TabIndex = 12;
            this.btnDDAOutputSave.Text = "SAVE";
            this.btnDDAOutputSave.UseVisualStyleBackColor = true;
            this.btnDDAOutputSave.Click += new System.EventHandler(this.btnDDAOutputSave_Click);
            // 
            // lblCfDDAOutputPisysFile
            // 
            this.lblCfDDAOutputPisysFile.AutoSize = true;
            this.lblCfDDAOutputPisysFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCfDDAOutputPisysFile.Location = new System.Drawing.Point(133, 38);
            this.lblCfDDAOutputPisysFile.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDAOutputPisysFile.Name = "lblCfDDAOutputPisysFile";
            this.lblCfDDAOutputPisysFile.Size = new System.Drawing.Size(60, 17);
            this.lblCfDDAOutputPisysFile.TabIndex = 2;
            this.lblCfDDAOutputPisysFile.Text = "[FileList]";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.tableLayoutPanel5);
            this.tabPage5.Location = new System.Drawing.Point(124, 4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(993, 536);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "DDP Report";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 380F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 505F));
            this.tableLayoutPanel5.Controls.Add(this.label14, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.txtCfDDPRejRptEmailHm, 1, 6);
            this.tableLayoutPanel5.Controls.Add(this.txtCfDDPRejRptHm, 1, 5);
            this.tableLayoutPanel5.Controls.Add(this.txtCfDDPRejRptEmail, 1, 4);
            this.tableLayoutPanel5.Controls.Add(this.lblCfDDPRejRpt, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.lblCfDDPRejRptEmail, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.lblCfDDPRejRptHm, 0, 5);
            this.tableLayoutPanel5.Controls.Add(this.lblCfDDPRejRptEmailHm, 0, 6);
            this.tableLayoutPanel5.Controls.Add(this.txtCFDDPRejRpt, 1, 3);
            this.tableLayoutPanel5.Controls.Add(this.btnDDPRptSave, 1, 7);
            this.tableLayoutPanel5.Controls.Add(this.label10, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.label12, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.txtCFDDPSbmRpt, 1, 1);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(15, 17);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 8;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(885, 494);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(3, 13);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 17);
            this.label14.TabIndex = 12;
            this.label14.Text = "To Citi";
            // 
            // txtCfDDPRejRptEmailHm
            // 
            this.txtCfDDPRejRptEmailHm.Location = new System.Drawing.Point(383, 333);
            this.txtCfDDPRejRptEmailHm.Multiline = true;
            this.txtCfDDPRejRptEmailHm.Name = "txtCfDDPRejRptEmailHm";
            this.txtCfDDPRejRptEmailHm.Size = new System.Drawing.Size(463, 53);
            this.txtCfDDPRejRptEmailHm.TabIndex = 9;
            // 
            // txtCfDDPRejRptHm
            // 
            this.txtCfDDPRejRptHm.Location = new System.Drawing.Point(383, 253);
            this.txtCfDDPRejRptHm.Name = "txtCfDDPRejRptHm";
            this.txtCfDDPRejRptHm.Size = new System.Drawing.Size(463, 23);
            this.txtCfDDPRejRptHm.TabIndex = 8;
            // 
            // txtCfDDPRejRptEmail
            // 
            this.txtCfDDPRejRptEmail.Location = new System.Drawing.Point(383, 173);
            this.txtCfDDPRejRptEmail.Multiline = true;
            this.txtCfDDPRejRptEmail.Name = "txtCfDDPRejRptEmail";
            this.txtCfDDPRejRptEmail.Size = new System.Drawing.Size(463, 53);
            this.txtCfDDPRejRptEmail.TabIndex = 7;
            // 
            // lblCfDDPRejRpt
            // 
            this.lblCfDDPRejRpt.AutoSize = true;
            this.lblCfDDPRejRpt.Location = new System.Drawing.Point(3, 116);
            this.lblCfDDPRejRpt.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDPRejRpt.Name = "lblCfDDPRejRpt";
            this.lblCfDDPRejRpt.Size = new System.Drawing.Size(301, 17);
            this.lblCfDDPRejRpt.TabIndex = 0;
            this.lblCfDDPRejRpt.Text = "Output Folder For DDP Rejection Report";
            // 
            // lblCfDDPRejRptEmail
            // 
            this.lblCfDDPRejRptEmail.AutoSize = true;
            this.lblCfDDPRejRptEmail.Location = new System.Drawing.Point(3, 176);
            this.lblCfDDPRejRptEmail.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDPRejRptEmail.Name = "lblCfDDPRejRptEmail";
            this.lblCfDDPRejRptEmail.Size = new System.Drawing.Size(271, 17);
            this.lblCfDDPRejRptEmail.TabIndex = 3;
            this.lblCfDDPRejRptEmail.Text = "Email List For DDP Rejection Report";
            // 
            // lblCfDDPRejRptHm
            // 
            this.lblCfDDPRejRptHm.AutoSize = true;
            this.lblCfDDPRejRptHm.Location = new System.Drawing.Point(3, 256);
            this.lblCfDDPRejRptHm.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDPRejRptHm.Name = "lblCfDDPRejRptHm";
            this.lblCfDDPRejRptHm.Size = new System.Drawing.Size(358, 34);
            this.lblCfDDPRejRptHm.TabIndex = 4;
            this.lblCfDDPRejRptHm.Text = "Output Folder For DDP Rejection Report (Home Case)";
            // 
            // lblCfDDPRejRptEmailHm
            // 
            this.lblCfDDPRejRptEmailHm.AutoSize = true;
            this.lblCfDDPRejRptEmailHm.Location = new System.Drawing.Point(3, 336);
            this.lblCfDDPRejRptEmailHm.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblCfDDPRejRptEmailHm.Name = "lblCfDDPRejRptEmailHm";
            this.lblCfDDPRejRptEmailHm.Size = new System.Drawing.Size(370, 17);
            this.lblCfDDPRejRptEmailHm.TabIndex = 5;
            this.lblCfDDPRejRptEmailHm.Text = "Email List For DDP Rejection Report (Home Case)";
            // 
            // txtCFDDPRejRpt
            // 
            this.txtCFDDPRejRpt.Location = new System.Drawing.Point(383, 113);
            this.txtCFDDPRejRpt.Name = "txtCFDDPRejRpt";
            this.txtCFDDPRejRpt.Size = new System.Drawing.Size(463, 23);
            this.txtCFDDPRejRpt.TabIndex = 6;
            // 
            // btnDDPRptSave
            // 
            this.btnDDPRptSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDDPRptSave.Location = new System.Drawing.Point(751, 433);
            this.btnDDPRptSave.Margin = new System.Windows.Forms.Padding(3, 3, 20, 3);
            this.btnDDPRptSave.Name = "btnDDPRptSave";
            this.btnDDPRptSave.Size = new System.Drawing.Size(114, 37);
            this.btnDDPRptSave.TabIndex = 2;
            this.btnDDPRptSave.Text = "SAVE";
            this.btnDDPRptSave.UseVisualStyleBackColor = true;
            this.btnDDPRptSave.Click += new System.EventHandler(this.btnDDPRptSave_Click);
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(3, 93);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 17);
            this.label10.TabIndex = 10;
            this.label10.Text = "From Citi";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 36);
            this.label12.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(315, 17);
            this.label12.TabIndex = 11;
            this.label12.Text = "Output Folder For DDP Submission Report";
            // 
            // txtCFDDPSbmRpt
            // 
            this.txtCFDDPSbmRpt.Location = new System.Drawing.Point(383, 33);
            this.txtCFDDPSbmRpt.Name = "txtCFDDPSbmRpt";
            this.txtCFDDPSbmRpt.Size = new System.Drawing.Size(463, 23);
            this.txtCFDDPSbmRpt.TabIndex = 13;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.tableLayoutPanel12);
            this.tabPage6.Controls.Add(this.tableLayoutPanel7);
            this.tabPage6.Location = new System.Drawing.Point(124, 4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(993, 536);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Others";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 1;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel12.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.label18, 0, 1);
            this.tableLayoutPanel12.Location = new System.Drawing.Point(10, 14);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(915, 45);
            this.tableLayoutPanel12.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(3, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(572, 17);
            this.label16.TabIndex = 0;
            this.label16.Text = "Mapping of client code and scheme name into corresponding Principal system";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(3, 22);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(637, 17);
            this.label18.TabIndex = 1;
            this.label18.Text = "(\"-\" to separate client code and scheme name. \";\" to separate each pair of client" +
    " code)";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 750F));
            this.tableLayoutPanel7.Controls.Add(this.btnCfSaveDDASetup, 1, 4);
            this.tableLayoutPanel7.Controls.Add(this.txtClientCodePisysCobrd, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.txtClientCodePisysCore, 1, 1);
            this.tableLayoutPanel7.Controls.Add(this.txtClientCodeHitrust, 1, 2);
            this.tableLayoutPanel7.Controls.Add(this.label4, 0, 3);
            this.tableLayoutPanel7.Controls.Add(this.label2, 0, 2);
            this.tableLayoutPanel7.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.label6, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.txtClientCodeESPP, 1, 3);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(11, 79);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 5;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(950, 393);
            this.tableLayoutPanel7.TabIndex = 1;
            // 
            // btnCfSaveDDASetup
            // 
            this.btnCfSaveDDASetup.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCfSaveDDASetup.Location = new System.Drawing.Point(816, 303);
            this.btnCfSaveDDASetup.Margin = new System.Windows.Forms.Padding(3, 3, 20, 3);
            this.btnCfSaveDDASetup.Name = "btnCfSaveDDASetup";
            this.btnCfSaveDDASetup.Size = new System.Drawing.Size(114, 37);
            this.btnCfSaveDDASetup.TabIndex = 2;
            this.btnCfSaveDDASetup.Text = "SAVE";
            this.btnCfSaveDDASetup.UseVisualStyleBackColor = true;
            this.btnCfSaveDDASetup.Click += new System.EventHandler(this.btnCfSaveDDASetup_Click);
            // 
            // txtClientCodePisysCobrd
            // 
            this.txtClientCodePisysCobrd.Location = new System.Drawing.Point(203, 3);
            this.txtClientCodePisysCobrd.Name = "txtClientCodePisysCobrd";
            this.txtClientCodePisysCobrd.Size = new System.Drawing.Size(711, 23);
            this.txtClientCodePisysCobrd.TabIndex = 6;
            // 
            // txtClientCodePisysCore
            // 
            this.txtClientCodePisysCore.Location = new System.Drawing.Point(203, 63);
            this.txtClientCodePisysCore.Name = "txtClientCodePisysCore";
            this.txtClientCodePisysCore.Size = new System.Drawing.Size(711, 23);
            this.txtClientCodePisysCore.TabIndex = 10;
            // 
            // txtClientCodeHitrust
            // 
            this.txtClientCodeHitrust.Location = new System.Drawing.Point(203, 123);
            this.txtClientCodeHitrust.Name = "txtClientCodeHitrust";
            this.txtClientCodeHitrust.Size = new System.Drawing.Size(711, 23);
            this.txtClientCodeHitrust.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 186);
            this.label4.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "ESPP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 126);
            this.label2.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "HiTrust";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 6);
            this.label8.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 17);
            this.label8.TabIndex = 12;
            this.label8.Text = "Pisys(cobrand)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 66);
            this.label6.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 17);
            this.label6.TabIndex = 9;
            this.label6.Text = "Pisys(core)";
            // 
            // txtClientCodeESPP
            // 
            this.txtClientCodeESPP.Location = new System.Drawing.Point(203, 183);
            this.txtClientCodeESPP.Name = "txtClientCodeESPP";
            this.txtClientCodeESPP.Size = new System.Drawing.Size(711, 23);
            this.txtClientCodeESPP.TabIndex = 13;
            // 
            // tabPageFromCiti
            // 
            this.tabPageFromCiti.Controls.Add(this.btnResetFromCiti);
            this.tabPageFromCiti.Controls.Add(this.tabControlFromCiti);
            this.tabPageFromCiti.Location = new System.Drawing.Point(4, 34);
            this.tabPageFromCiti.Name = "tabPageFromCiti";
            this.tabPageFromCiti.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFromCiti.Size = new System.Drawing.Size(1184, 747);
            this.tabPageFromCiti.TabIndex = 1;
            this.tabPageFromCiti.Text = "From Citi";
            this.tabPageFromCiti.UseVisualStyleBackColor = true;
            // 
            // btnResetFromCiti
            // 
            this.btnResetFromCiti.Location = new System.Drawing.Point(44, 658);
            this.btnResetFromCiti.Name = "btnResetFromCiti";
            this.btnResetFromCiti.Size = new System.Drawing.Size(92, 44);
            this.btnResetFromCiti.TabIndex = 2;
            this.btnResetFromCiti.Text = "Reset All";
            this.btnResetFromCiti.UseVisualStyleBackColor = true;
            this.btnResetFromCiti.Click += new System.EventHandler(this.btnResetFromCiti_Click);
            // 
            // tabControlFromCiti
            // 
            this.tabControlFromCiti.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControlFromCiti.Controls.Add(this.tabPageFromCitiStep1);
            this.tabControlFromCiti.Controls.Add(this.tabPageFromCitiStep2);
            this.tabControlFromCiti.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tabControlFromCiti.ItemSize = new System.Drawing.Size(30, 120);
            this.tabControlFromCiti.Location = new System.Drawing.Point(42, 34);
            this.tabControlFromCiti.Multiline = true;
            this.tabControlFromCiti.Name = "tabControlFromCiti";
            this.tabControlFromCiti.SelectedIndex = 0;
            this.tabControlFromCiti.Size = new System.Drawing.Size(1034, 605);
            this.tabControlFromCiti.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControlFromCiti.TabIndex = 1;
            this.tabControlFromCiti.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabControlFromCiti_DrawItem);
            this.tabControlFromCiti.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControlFromCiti_Selecting);
            // 
            // tabPageFromCitiStep1
            // 
            this.tabPageFromCitiStep1.Controls.Add(this.dataGridViewFrmCitiFileList);
            this.tabPageFromCitiStep1.Controls.Add(this.btnFromCitiStep1Next);
            this.tabPageFromCitiStep1.Controls.Add(this.tableLayoutPanel6);
            this.tabPageFromCitiStep1.Location = new System.Drawing.Point(124, 4);
            this.tabPageFromCitiStep1.Name = "tabPageFromCitiStep1";
            this.tabPageFromCitiStep1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFromCitiStep1.Size = new System.Drawing.Size(906, 597);
            this.tabPageFromCitiStep1.TabIndex = 4;
            this.tabPageFromCitiStep1.Text = "01. Load File";
            this.tabPageFromCitiStep1.UseVisualStyleBackColor = true;
            // 
            // dataGridViewFrmCitiFileList
            // 
            this.dataGridViewFrmCitiFileList.AllowUserToAddRows = false;
            this.dataGridViewFrmCitiFileList.AllowUserToDeleteRows = false;
            this.dataGridViewFrmCitiFileList.AutoGenerateColumns = false;
            this.dataGridViewFrmCitiFileList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewFrmCitiFileList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFrmCitiFileList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.fileNameDataGridViewTextBoxColumn,
            this.filePathDataGridViewTextBoxColumn,
            this.FromCitiDeleteFile});
            this.dataGridViewFrmCitiFileList.DataSource = this.fileListBindingSource;
            this.dataGridViewFrmCitiFileList.Location = new System.Drawing.Point(26, 74);
            this.dataGridViewFrmCitiFileList.Name = "dataGridViewFrmCitiFileList";
            this.dataGridViewFrmCitiFileList.ReadOnly = true;
            this.dataGridViewFrmCitiFileList.Size = new System.Drawing.Size(848, 389);
            this.dataGridViewFrmCitiFileList.TabIndex = 10;
            this.dataGridViewFrmCitiFileList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewFrmCitiFileList_CellContentClick);
            // 
            // fileNameDataGridViewTextBoxColumn
            // 
            this.fileNameDataGridViewTextBoxColumn.DataPropertyName = "fileName";
            this.fileNameDataGridViewTextBoxColumn.FillWeight = 70F;
            this.fileNameDataGridViewTextBoxColumn.HeaderText = "File Name";
            this.fileNameDataGridViewTextBoxColumn.Name = "fileNameDataGridViewTextBoxColumn";
            this.fileNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // filePathDataGridViewTextBoxColumn
            // 
            this.filePathDataGridViewTextBoxColumn.DataPropertyName = "filePath";
            this.filePathDataGridViewTextBoxColumn.HeaderText = "File Path";
            this.filePathDataGridViewTextBoxColumn.Name = "filePathDataGridViewTextBoxColumn";
            this.filePathDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // FromCitiDeleteFile
            // 
            this.FromCitiDeleteFile.FillWeight = 20F;
            this.FromCitiDeleteFile.HeaderText = "Action";
            this.FromCitiDeleteFile.Name = "FromCitiDeleteFile";
            this.FromCitiDeleteFile.ReadOnly = true;
            this.FromCitiDeleteFile.Text = "Exclude";
            this.FromCitiDeleteFile.UseColumnTextForButtonValue = true;
            // 
            // fileListBindingSource
            // 
            this.fileListBindingSource.DataSource = typeof(eDDA.FileList);
            // 
            // btnFromCitiStep1Next
            // 
            this.btnFromCitiStep1Next.BackColor = System.Drawing.Color.SteelBlue;
            this.btnFromCitiStep1Next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFromCitiStep1Next.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnFromCitiStep1Next.Location = new System.Drawing.Point(789, 537);
            this.btnFromCitiStep1Next.Name = "btnFromCitiStep1Next";
            this.btnFromCitiStep1Next.Size = new System.Drawing.Size(85, 34);
            this.btnFromCitiStep1Next.TabIndex = 9;
            this.btnFromCitiStep1Next.Text = "NEXT >>";
            this.btnFromCitiStep1Next.UseVisualStyleBackColor = false;
            this.btnFromCitiStep1Next.Click += new System.EventHandler(this.btnFromCitiStep1Next_Click);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 6;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 180F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel6.Controls.Add(this.dateFromCitiFromDt, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.btnImportXml, 5, 0);
            this.tableLayoutPanel6.Controls.Add(this.panel1, 4, 0);
            this.tableLayoutPanel6.Controls.Add(this.label34, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.lblToDateFromCiti, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this.dateFromCitiToDt, 3, 0);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(39, 16);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 52F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(759, 52);
            this.tableLayoutPanel6.TabIndex = 1;
            // 
            // dateFromCitiFromDt
            // 
            this.dateFromCitiFromDt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)), true);
            this.dateFromCitiFromDt.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateFromCitiFromDt.Location = new System.Drawing.Point(143, 3);
            this.dateFromCitiFromDt.Name = "dateFromCitiFromDt";
            this.dateFromCitiFromDt.Size = new System.Drawing.Size(102, 23);
            this.dateFromCitiFromDt.TabIndex = 2;
            // 
            // btnImportXml
            // 
            this.btnImportXml.Enabled = false;
            this.btnImportXml.Location = new System.Drawing.Point(663, 3);
            this.btnImportXml.Name = "btnImportXml";
            this.btnImportXml.Size = new System.Drawing.Size(80, 27);
            this.btnImportXml.TabIndex = 4;
            this.btnImportXml.Text = "Import";
            this.btnImportXml.UseVisualStyleBackColor = true;
            this.btnImportXml.Click += new System.EventHandler(this.btnImportXml_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioBtnDDPFromCiti);
            this.panel1.Controls.Add(this.radioBtnDDAFromCiti);
            this.panel1.Location = new System.Drawing.Point(483, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(133, 28);
            this.panel1.TabIndex = 3;
            // 
            // radioBtnDDPFromCiti
            // 
            this.radioBtnDDPFromCiti.AutoSize = true;
            this.radioBtnDDPFromCiti.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.radioBtnDDPFromCiti.Location = new System.Drawing.Point(65, 5);
            this.radioBtnDDPFromCiti.Name = "radioBtnDDPFromCiti";
            this.radioBtnDDPFromCiti.Size = new System.Drawing.Size(54, 19);
            this.radioBtnDDPFromCiti.TabIndex = 1;
            this.radioBtnDDPFromCiti.TabStop = true;
            this.radioBtnDDPFromCiti.Text = "DDP";
            this.radioBtnDDPFromCiti.UseVisualStyleBackColor = true;
            this.radioBtnDDPFromCiti.Click += new System.EventHandler(this.radioBtnFromCiti_Click);
            // 
            // radioBtnDDAFromCiti
            // 
            this.radioBtnDDAFromCiti.AutoSize = true;
            this.radioBtnDDAFromCiti.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.radioBtnDDAFromCiti.Location = new System.Drawing.Point(6, 5);
            this.radioBtnDDAFromCiti.Name = "radioBtnDDAFromCiti";
            this.radioBtnDDAFromCiti.Size = new System.Drawing.Size(53, 19);
            this.radioBtnDDAFromCiti.TabIndex = 0;
            this.radioBtnDDAFromCiti.TabStop = true;
            this.radioBtnDDAFromCiti.Text = "DDA";
            this.radioBtnDDAFromCiti.UseVisualStyleBackColor = true;
            this.radioBtnDDAFromCiti.Click += new System.EventHandler(this.radioBtnFromCiti_Click);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label34.Location = new System.Drawing.Point(3, 6);
            this.label34.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(119, 15);
            this.label34.TabIndex = 0;
            this.label34.Text = "Import From Date";
            // 
            // lblToDateFromCiti
            // 
            this.lblToDateFromCiti.AutoSize = true;
            this.lblToDateFromCiti.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblToDateFromCiti.Location = new System.Drawing.Point(263, 6);
            this.lblToDateFromCiti.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblToDateFromCiti.Name = "lblToDateFromCiti";
            this.lblToDateFromCiti.Size = new System.Drawing.Size(57, 15);
            this.lblToDateFromCiti.TabIndex = 5;
            this.lblToDateFromCiti.Text = "To Date";
            // 
            // dateFromCitiToDt
            // 
            this.dateFromCitiToDt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dateFromCitiToDt.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateFromCitiToDt.Location = new System.Drawing.Point(353, 3);
            this.dateFromCitiToDt.Name = "dateFromCitiToDt";
            this.dateFromCitiToDt.Size = new System.Drawing.Size(102, 23);
            this.dateFromCitiToDt.TabIndex = 6;
            // 
            // tabPageFromCitiStep2
            // 
            this.tabPageFromCitiStep2.Controls.Add(this.btnFromCitiStep2Back);
            this.tabPageFromCitiStep2.Controls.Add(this.tableLayoutPanel8);
            this.tabPageFromCitiStep2.Location = new System.Drawing.Point(124, 4);
            this.tabPageFromCitiStep2.Name = "tabPageFromCitiStep2";
            this.tabPageFromCitiStep2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFromCitiStep2.Size = new System.Drawing.Size(906, 597);
            this.tabPageFromCitiStep2.TabIndex = 5;
            this.tabPageFromCitiStep2.Text = "02. Convert";
            this.tabPageFromCitiStep2.UseVisualStyleBackColor = true;
            // 
            // btnFromCitiStep2Back
            // 
            this.btnFromCitiStep2Back.BackColor = System.Drawing.Color.SteelBlue;
            this.btnFromCitiStep2Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFromCitiStep2Back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnFromCitiStep2Back.Location = new System.Drawing.Point(688, 449);
            this.btnFromCitiStep2Back.Name = "btnFromCitiStep2Back";
            this.btnFromCitiStep2Back.Size = new System.Drawing.Size(85, 34);
            this.btnFromCitiStep2Back.TabIndex = 10;
            this.btnFromCitiStep2Back.Text = "<< BACK";
            this.btnFromCitiStep2Back.UseVisualStyleBackColor = false;
            this.btnFromCitiStep2Back.Click += new System.EventHandler(this.btnFromCitiStep2Back_Click);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 4;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 399F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 82F));
            this.tableLayoutPanel8.Controls.Add(this.label36, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.btnFromCitiConvertTxt, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.label37, 2, 0);
            this.tableLayoutPanel8.Controls.Add(this.label38, 2, 1);
            this.tableLayoutPanel8.Controls.Add(this.label39, 0, 3);
            this.tableLayoutPanel8.Controls.Add(this.btnFromCitiGenRpt, 1, 3);
            this.tableLayoutPanel8.Controls.Add(this.label40, 2, 4);
            this.tableLayoutPanel8.Controls.Add(this.label41, 2, 3);
            this.tableLayoutPanel8.Controls.Add(this.label42, 2, 5);
            this.tableLayoutPanel8.Controls.Add(this.label43, 2, 6);
            this.tableLayoutPanel8.Controls.Add(this.label44, 0, 8);
            this.tableLayoutPanel8.Controls.Add(this.btnFromCitiSendeMail, 1, 8);
            this.tableLayoutPanel8.Controls.Add(this.label45, 2, 8);
            this.tableLayoutPanel8.Controls.Add(this.label46, 2, 9);
            this.tableLayoutPanel8.Controls.Add(this.label47, 2, 11);
            this.tableLayoutPanel8.Controls.Add(this.label48, 2, 10);
            this.tableLayoutPanel8.Location = new System.Drawing.Point(42, 27);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 12;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(731, 369);
            this.tableLayoutPanel8.TabIndex = 9;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label36.Location = new System.Drawing.Point(3, 6);
            this.label36.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(75, 15);
            this.label36.TabIndex = 0;
            this.label36.Text = "XML To TXT";
            // 
            // btnFromCitiConvertTxt
            // 
            this.btnFromCitiConvertTxt.Location = new System.Drawing.Point(153, 3);
            this.btnFromCitiConvertTxt.Name = "btnFromCitiConvertTxt";
            this.btnFromCitiConvertTxt.Size = new System.Drawing.Size(75, 24);
            this.btnFromCitiConvertTxt.TabIndex = 2;
            this.btnFromCitiConvertTxt.Text = "Convert";
            this.btnFromCitiConvertTxt.UseVisualStyleBackColor = true;
            this.btnFromCitiConvertTxt.Click += new System.EventHandler(this.btnFromCitiConvertTxt_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label37.Location = new System.Drawing.Point(253, 6);
            this.label37.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(70, 15);
            this.label37.TabIndex = 1;
            this.label37.Text = "Folder Path";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label38.Location = new System.Drawing.Point(253, 36);
            this.label38.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(293, 15);
            this.label38.TabIndex = 3;
            this.label38.Text = "J:\\Treasury\\Account Receivable\\DDCitidirect – Merge\\";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label39.Location = new System.Drawing.Point(3, 96);
            this.label39.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(118, 15);
            this.label39.TabIndex = 4;
            this.label39.Text = "DDP rejection report";
            // 
            // btnFromCitiGenRpt
            // 
            this.btnFromCitiGenRpt.Location = new System.Drawing.Point(153, 93);
            this.btnFromCitiGenRpt.Name = "btnFromCitiGenRpt";
            this.btnFromCitiGenRpt.Size = new System.Drawing.Size(94, 24);
            this.btnFromCitiGenRpt.TabIndex = 6;
            this.btnFromCitiGenRpt.Text = "Generate";
            this.btnFromCitiGenRpt.UseVisualStyleBackColor = true;
            this.btnFromCitiGenRpt.Click += new System.EventHandler(this.btnFromCitiGenRpt_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label40.Location = new System.Drawing.Point(253, 126);
            this.label40.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(67, 15);
            this.label40.TabIndex = 5;
            this.label40.Text = "U:\\???.xlsx";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label41.Location = new System.Drawing.Point(253, 96);
            this.label41.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(137, 15);
            this.label41.TabIndex = 7;
            this.label41.Text = "Non-Home Case Folder";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label42.Location = new System.Drawing.Point(253, 156);
            this.label42.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(110, 15);
            this.label42.TabIndex = 8;
            this.label42.Text = "Home Case Folder";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label43.Location = new System.Drawing.Point(253, 186);
            this.label43.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(67, 15);
            this.label43.TabIndex = 9;
            this.label43.Text = "U:\\???.xlsx";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label44.Location = new System.Drawing.Point(3, 246);
            this.label44.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(39, 15);
            this.label44.TabIndex = 10;
            this.label44.Text = "Email";
            // 
            // btnFromCitiSendeMail
            // 
            this.btnFromCitiSendeMail.Location = new System.Drawing.Point(153, 243);
            this.btnFromCitiSendeMail.Name = "btnFromCitiSendeMail";
            this.btnFromCitiSendeMail.Size = new System.Drawing.Size(84, 24);
            this.btnFromCitiSendeMail.TabIndex = 11;
            this.btnFromCitiSendeMail.Text = "Send Email";
            this.btnFromCitiSendeMail.UseVisualStyleBackColor = true;
            this.btnFromCitiSendeMail.Click += new System.EventHandler(this.btnFromCitiSendeMail_Click);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label45.Location = new System.Drawing.Point(253, 246);
            this.label45.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(156, 15);
            this.label45.TabIndex = 12;
            this.label45.Text = "Non-Home Case Email List";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label46.Location = new System.Drawing.Point(253, 276);
            this.label46.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(200, 15);
            this.label46.TabIndex = 13;
            this.label46.Text = "A@principal.com; B@principal.com";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label47.Location = new System.Drawing.Point(253, 336);
            this.label47.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(200, 15);
            this.label47.TabIndex = 15;
            this.label47.Text = "A@principal.com; B@principal.com";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label48.Location = new System.Drawing.Point(253, 306);
            this.label48.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(129, 15);
            this.label48.TabIndex = 14;
            this.label48.Text = "Home Case Email List";
            // 
            // tabPageToCiti
            // 
            this.tabPageToCiti.Controls.Add(this.btnResetToCiti);
            this.tabPageToCiti.Controls.Add(this.tabControlToCiti);
            this.tabPageToCiti.Location = new System.Drawing.Point(4, 34);
            this.tabPageToCiti.Name = "tabPageToCiti";
            this.tabPageToCiti.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageToCiti.Size = new System.Drawing.Size(1184, 747);
            this.tabPageToCiti.TabIndex = 2;
            this.tabPageToCiti.Text = "To Citi";
            this.tabPageToCiti.UseVisualStyleBackColor = true;
            // 
            // btnResetToCiti
            // 
            this.btnResetToCiti.Location = new System.Drawing.Point(21, 649);
            this.btnResetToCiti.Name = "btnResetToCiti";
            this.btnResetToCiti.Size = new System.Drawing.Size(92, 44);
            this.btnResetToCiti.TabIndex = 2;
            this.btnResetToCiti.Text = "Reset All";
            this.btnResetToCiti.UseVisualStyleBackColor = true;
            this.btnResetToCiti.Click += new System.EventHandler(this.btnResetToCiti_Click);
            // 
            // tabControlToCiti
            // 
            this.tabControlToCiti.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControlToCiti.Controls.Add(this.tabPageToCitiStep1);
            this.tabControlToCiti.Controls.Add(this.tabPageToCitiStep2);
            this.tabControlToCiti.Controls.Add(this.tabPageToCitiStep3);
            this.tabControlToCiti.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControlToCiti.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tabControlToCiti.ItemSize = new System.Drawing.Size(30, 120);
            this.tabControlToCiti.Location = new System.Drawing.Point(3, 3);
            this.tabControlToCiti.Margin = new System.Windows.Forms.Padding(10, 20, 3, 3);
            this.tabControlToCiti.Multiline = true;
            this.tabControlToCiti.Name = "tabControlToCiti";
            this.tabControlToCiti.SelectedIndex = 0;
            this.tabControlToCiti.Size = new System.Drawing.Size(1178, 626);
            this.tabControlToCiti.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControlToCiti.TabIndex = 1;
            this.tabControlToCiti.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabControlToCiti_DrawItem);
            this.tabControlToCiti.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControlToCiti_Selecting);
            // 
            // tabPageToCitiStep1
            // 
            this.tabPageToCitiStep1.Controls.Add(this.tableLayoutPanel10);
            this.tabPageToCitiStep1.Controls.Add(this.btnToCitiStep1Next);
            this.tabPageToCitiStep1.Controls.Add(this.dataGridViewToCitiFileList);
            this.tabPageToCitiStep1.Controls.Add(this.tableLayoutPanel9);
            this.tabPageToCitiStep1.Location = new System.Drawing.Point(124, 4);
            this.tabPageToCitiStep1.Name = "tabPageToCitiStep1";
            this.tabPageToCitiStep1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageToCitiStep1.Size = new System.Drawing.Size(1050, 618);
            this.tabPageToCitiStep1.TabIndex = 2;
            this.tabPageToCitiStep1.Text = "01. Load File";
            this.tabPageToCitiStep1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 1;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Controls.Add(this.labelValidateMsg, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.textBoxValidateMsg, 0, 1);
            this.tableLayoutPanel10.Location = new System.Drawing.Point(26, 481);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 2;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(773, 126);
            this.tableLayoutPanel10.TabIndex = 8;
            // 
            // labelValidateMsg
            // 
            this.labelValidateMsg.AutoSize = true;
            this.labelValidateMsg.Location = new System.Drawing.Point(0, 6);
            this.labelValidateMsg.Margin = new System.Windows.Forms.Padding(0, 6, 3, 0);
            this.labelValidateMsg.Name = "labelValidateMsg";
            this.labelValidateMsg.Size = new System.Drawing.Size(154, 17);
            this.labelValidateMsg.TabIndex = 0;
            this.labelValidateMsg.Text = "Validation Message:";
            // 
            // textBoxValidateMsg
            // 
            this.textBoxValidateMsg.Location = new System.Drawing.Point(3, 28);
            this.textBoxValidateMsg.Multiline = true;
            this.textBoxValidateMsg.Name = "textBoxValidateMsg";
            this.textBoxValidateMsg.ReadOnly = true;
            this.textBoxValidateMsg.Size = new System.Drawing.Size(757, 88);
            this.textBoxValidateMsg.TabIndex = 1;
            // 
            // btnToCitiStep1Next
            // 
            this.btnToCitiStep1Next.BackColor = System.Drawing.Color.SteelBlue;
            this.btnToCitiStep1Next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnToCitiStep1Next.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnToCitiStep1Next.Location = new System.Drawing.Point(805, 506);
            this.btnToCitiStep1Next.Name = "btnToCitiStep1Next";
            this.btnToCitiStep1Next.Size = new System.Drawing.Size(85, 34);
            this.btnToCitiStep1Next.TabIndex = 7;
            this.btnToCitiStep1Next.Text = "NEXT >>";
            this.btnToCitiStep1Next.UseVisualStyleBackColor = false;
            this.btnToCitiStep1Next.Click += new System.EventHandler(this.btnToCitiStep1Next_Click);
            // 
            // dataGridViewToCitiFileList
            // 
            this.dataGridViewToCitiFileList.AllowUserToAddRows = false;
            this.dataGridViewToCitiFileList.AllowUserToDeleteRows = false;
            this.dataGridViewToCitiFileList.AutoGenerateColumns = false;
            this.dataGridViewToCitiFileList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewToCitiFileList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewToCitiFileList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.toCitiFileDelete});
            this.dataGridViewToCitiFileList.DataSource = this.fileListBindingSource;
            this.dataGridViewToCitiFileList.Location = new System.Drawing.Point(26, 71);
            this.dataGridViewToCitiFileList.Name = "dataGridViewToCitiFileList";
            this.dataGridViewToCitiFileList.ReadOnly = true;
            this.dataGridViewToCitiFileList.Size = new System.Drawing.Size(864, 398);
            this.dataGridViewToCitiFileList.TabIndex = 3;
            this.dataGridViewToCitiFileList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewToCitiFileList_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "fileName";
            this.dataGridViewTextBoxColumn1.FillWeight = 70F;
            this.dataGridViewTextBoxColumn1.HeaderText = "File Name";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "filePath";
            this.dataGridViewTextBoxColumn2.HeaderText = "File Path";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // toCitiFileDelete
            // 
            this.toCitiFileDelete.FillWeight = 20F;
            this.toCitiFileDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.toCitiFileDelete.HeaderText = "Action";
            this.toCitiFileDelete.Name = "toCitiFileDelete";
            this.toCitiFileDelete.ReadOnly = true;
            this.toCitiFileDelete.Text = "Remove";
            this.toCitiFileDelete.UseColumnTextForButtonValue = true;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 6;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 180F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 189F));
            this.tableLayoutPanel9.Controls.Add(this.dateToCitiFromDt, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.label49, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.buttonImport, 5, 0);
            this.tableLayoutPanel9.Controls.Add(this.panel2, 4, 0);
            this.tableLayoutPanel9.Controls.Add(this.label56, 2, 0);
            this.tableLayoutPanel9.Controls.Add(this.dateToCitiToDt, 3, 0);
            this.tableLayoutPanel9.Location = new System.Drawing.Point(26, 6);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(829, 47);
            this.tableLayoutPanel9.TabIndex = 2;
            // 
            // dateToCitiFromDt
            // 
            this.dateToCitiFromDt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dateToCitiFromDt.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateToCitiFromDt.Location = new System.Drawing.Point(143, 3);
            this.dateToCitiFromDt.Name = "dateToCitiFromDt";
            this.dateToCitiFromDt.Size = new System.Drawing.Size(102, 23);
            this.dateToCitiFromDt.TabIndex = 1;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label49.Location = new System.Drawing.Point(3, 6);
            this.label49.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(119, 15);
            this.label49.TabIndex = 0;
            this.label49.Text = "Import From Date";
            // 
            // buttonImport
            // 
            this.buttonImport.BackColor = System.Drawing.SystemColors.Control;
            this.buttonImport.Enabled = false;
            this.buttonImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonImport.Location = new System.Drawing.Point(663, 3);
            this.buttonImport.Name = "buttonImport";
            this.buttonImport.Size = new System.Drawing.Size(85, 34);
            this.buttonImport.TabIndex = 3;
            this.buttonImport.Text = "Import";
            this.buttonImport.UseVisualStyleBackColor = false;
            this.buttonImport.Click += new System.EventHandler(this.buttonImport_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioBtnDDPToCiti);
            this.panel2.Controls.Add(this.radioBtnDDAToCiti);
            this.panel2.Location = new System.Drawing.Point(483, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(142, 29);
            this.panel2.TabIndex = 2;
            // 
            // radioBtnDDPToCiti
            // 
            this.radioBtnDDPToCiti.AutoSize = true;
            this.radioBtnDDPToCiti.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.radioBtnDDPToCiti.Location = new System.Drawing.Point(65, 4);
            this.radioBtnDDPToCiti.Name = "radioBtnDDPToCiti";
            this.radioBtnDDPToCiti.Size = new System.Drawing.Size(54, 19);
            this.radioBtnDDPToCiti.TabIndex = 1;
            this.radioBtnDDPToCiti.TabStop = true;
            this.radioBtnDDPToCiti.Text = "DDP";
            this.radioBtnDDPToCiti.UseVisualStyleBackColor = true;
            this.radioBtnDDPToCiti.Click += new System.EventHandler(this.radioBtnToCiti_Click);
            // 
            // radioBtnDDAToCiti
            // 
            this.radioBtnDDAToCiti.AutoSize = true;
            this.radioBtnDDAToCiti.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.radioBtnDDAToCiti.Location = new System.Drawing.Point(3, 4);
            this.radioBtnDDAToCiti.Name = "radioBtnDDAToCiti";
            this.radioBtnDDAToCiti.Size = new System.Drawing.Size(53, 19);
            this.radioBtnDDAToCiti.TabIndex = 0;
            this.radioBtnDDAToCiti.TabStop = true;
            this.radioBtnDDAToCiti.Text = "DDA";
            this.radioBtnDDAToCiti.UseVisualStyleBackColor = true;
            this.radioBtnDDAToCiti.Click += new System.EventHandler(this.radioBtnToCiti_Click);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label56.Location = new System.Drawing.Point(263, 6);
            this.label56.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(57, 15);
            this.label56.TabIndex = 4;
            this.label56.Text = "To Date";
            // 
            // dateToCitiToDt
            // 
            this.dateToCitiToDt.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateToCitiToDt.Location = new System.Drawing.Point(353, 3);
            this.dateToCitiToDt.Name = "dateToCitiToDt";
            this.dateToCitiToDt.Size = new System.Drawing.Size(107, 23);
            this.dateToCitiToDt.TabIndex = 5;
            // 
            // tabPageToCitiStep2
            // 
            this.tabPageToCitiStep2.Controls.Add(this.buttonCombine);
            this.tabPageToCitiStep2.Controls.Add(this.btnToCitiStep2Back);
            this.tabPageToCitiStep2.Controls.Add(this.btnToCitiStep2Next);
            this.tabPageToCitiStep2.Controls.Add(this.dataGridViewToCitiData);
            this.tabPageToCitiStep2.Location = new System.Drawing.Point(124, 4);
            this.tabPageToCitiStep2.Name = "tabPageToCitiStep2";
            this.tabPageToCitiStep2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageToCitiStep2.Size = new System.Drawing.Size(1050, 618);
            this.tabPageToCitiStep2.TabIndex = 3;
            this.tabPageToCitiStep2.Text = "02. Data Adj.";
            this.tabPageToCitiStep2.UseVisualStyleBackColor = true;
            // 
            // buttonCombine
            // 
            this.buttonCombine.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCombine.Location = new System.Drawing.Point(965, 514);
            this.buttonCombine.Name = "buttonCombine";
            this.buttonCombine.Size = new System.Drawing.Size(79, 36);
            this.buttonCombine.TabIndex = 12;
            this.buttonCombine.Text = "Combine";
            this.buttonCombine.UseVisualStyleBackColor = true;
            this.buttonCombine.Click += new System.EventHandler(this.buttonCombine_Click);
            // 
            // btnToCitiStep2Back
            // 
            this.btnToCitiStep2Back.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnToCitiStep2Back.BackColor = System.Drawing.Color.SteelBlue;
            this.btnToCitiStep2Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnToCitiStep2Back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnToCitiStep2Back.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnToCitiStep2Back.Location = new System.Drawing.Point(808, 566);
            this.btnToCitiStep2Back.Name = "btnToCitiStep2Back";
            this.btnToCitiStep2Back.Size = new System.Drawing.Size(85, 34);
            this.btnToCitiStep2Back.TabIndex = 11;
            this.btnToCitiStep2Back.Text = "<< BACK";
            this.btnToCitiStep2Back.UseVisualStyleBackColor = false;
            this.btnToCitiStep2Back.Click += new System.EventHandler(this.btnToCitiStep2Back_Click);
            // 
            // btnToCitiStep2Next
            // 
            this.btnToCitiStep2Next.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnToCitiStep2Next.BackColor = System.Drawing.Color.SteelBlue;
            this.btnToCitiStep2Next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnToCitiStep2Next.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnToCitiStep2Next.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnToCitiStep2Next.Location = new System.Drawing.Point(931, 566);
            this.btnToCitiStep2Next.Name = "btnToCitiStep2Next";
            this.btnToCitiStep2Next.Size = new System.Drawing.Size(85, 34);
            this.btnToCitiStep2Next.TabIndex = 10;
            this.btnToCitiStep2Next.Text = "NEXT >>";
            this.btnToCitiStep2Next.UseVisualStyleBackColor = false;
            this.btnToCitiStep2Next.Click += new System.EventHandler(this.btnToCitiStep2Next_Click);
            // 
            // dataGridViewToCitiData
            // 
            this.dataGridViewToCitiData.AllowUserToAddRows = false;
            this.dataGridViewToCitiData.AllowUserToDeleteRows = false;
            this.dataGridViewToCitiData.AutoGenerateColumns = false;
            this.dataGridViewToCitiData.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewToCitiData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewToCitiData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.recordID,
            this.fileNameDataGridViewTextBoxColumn1,
            this.amountDataGridViewTextBoxColumn,
            this.clientCodeDataGridViewTextBoxColumn,
            this.clientReferenceDataGridViewTextBoxColumn,
            this.payAmountDataGridViewTextBoxColumn,
            this.payerNameDataGridViewTextBoxColumn,
            this.valueDateDataGridViewTextBoxColumn,
            this.ToCitiDataEdit,
            this.ToCitiDataDelete,
            this.ToCitiDataCombine});
            this.dataGridViewToCitiData.DataSource = this.toCitiDataBindingSource;
            this.dataGridViewToCitiData.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridViewToCitiData.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewToCitiData.Margin = new System.Windows.Forms.Padding(10, 20, 10, 3);
            this.dataGridViewToCitiData.Name = "dataGridViewToCitiData";
            this.dataGridViewToCitiData.ReadOnly = true;
            this.dataGridViewToCitiData.Size = new System.Drawing.Size(1044, 502);
            this.dataGridViewToCitiData.TabIndex = 0;
            this.dataGridViewToCitiData.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewToCitiData_CellContentClick);
            // 
            // recordID
            // 
            this.recordID.DataPropertyName = "recordID";
            this.recordID.FillWeight = 30F;
            this.recordID.HeaderText = "Record ID";
            this.recordID.Name = "recordID";
            this.recordID.ReadOnly = true;
            this.recordID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // fileNameDataGridViewTextBoxColumn1
            // 
            this.fileNameDataGridViewTextBoxColumn1.DataPropertyName = "fileName";
            this.fileNameDataGridViewTextBoxColumn1.FillWeight = 80F;
            this.fileNameDataGridViewTextBoxColumn1.HeaderText = "File Name";
            this.fileNameDataGridViewTextBoxColumn1.Name = "fileNameDataGridViewTextBoxColumn1";
            this.fileNameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.fileNameDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // amountDataGridViewTextBoxColumn
            // 
            this.amountDataGridViewTextBoxColumn.DataPropertyName = "amount";
            this.amountDataGridViewTextBoxColumn.FillWeight = 50F;
            this.amountDataGridViewTextBoxColumn.HeaderText = "Amount";
            this.amountDataGridViewTextBoxColumn.Name = "amountDataGridViewTextBoxColumn";
            this.amountDataGridViewTextBoxColumn.ReadOnly = true;
            this.amountDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // clientCodeDataGridViewTextBoxColumn
            // 
            this.clientCodeDataGridViewTextBoxColumn.DataPropertyName = "clientCode";
            this.clientCodeDataGridViewTextBoxColumn.FillWeight = 40F;
            this.clientCodeDataGridViewTextBoxColumn.HeaderText = "Client Code";
            this.clientCodeDataGridViewTextBoxColumn.Name = "clientCodeDataGridViewTextBoxColumn";
            this.clientCodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.clientCodeDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // clientReferenceDataGridViewTextBoxColumn
            // 
            this.clientReferenceDataGridViewTextBoxColumn.DataPropertyName = "clientReference";
            this.clientReferenceDataGridViewTextBoxColumn.FillWeight = 50F;
            this.clientReferenceDataGridViewTextBoxColumn.HeaderText = "Client Reference";
            this.clientReferenceDataGridViewTextBoxColumn.Name = "clientReferenceDataGridViewTextBoxColumn";
            this.clientReferenceDataGridViewTextBoxColumn.ReadOnly = true;
            this.clientReferenceDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // payAmountDataGridViewTextBoxColumn
            // 
            this.payAmountDataGridViewTextBoxColumn.DataPropertyName = "payAmount";
            this.payAmountDataGridViewTextBoxColumn.FillWeight = 50F;
            this.payAmountDataGridViewTextBoxColumn.HeaderText = "Payer Amount";
            this.payAmountDataGridViewTextBoxColumn.Name = "payAmountDataGridViewTextBoxColumn";
            this.payAmountDataGridViewTextBoxColumn.ReadOnly = true;
            this.payAmountDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // payerNameDataGridViewTextBoxColumn
            // 
            this.payerNameDataGridViewTextBoxColumn.DataPropertyName = "payerName";
            this.payerNameDataGridViewTextBoxColumn.FillWeight = 80F;
            this.payerNameDataGridViewTextBoxColumn.HeaderText = "Payer Name";
            this.payerNameDataGridViewTextBoxColumn.Name = "payerNameDataGridViewTextBoxColumn";
            this.payerNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.payerNameDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // valueDateDataGridViewTextBoxColumn
            // 
            this.valueDateDataGridViewTextBoxColumn.DataPropertyName = "valueDate";
            this.valueDateDataGridViewTextBoxColumn.FillWeight = 50F;
            this.valueDateDataGridViewTextBoxColumn.HeaderText = "Value Date";
            this.valueDateDataGridViewTextBoxColumn.Name = "valueDateDataGridViewTextBoxColumn";
            this.valueDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.valueDateDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ToCitiDataEdit
            // 
            this.ToCitiDataEdit.FillWeight = 30F;
            this.ToCitiDataEdit.HeaderText = "Edit";
            this.ToCitiDataEdit.Name = "ToCitiDataEdit";
            this.ToCitiDataEdit.ReadOnly = true;
            this.ToCitiDataEdit.Text = "Edit";
            this.ToCitiDataEdit.UseColumnTextForButtonValue = true;
            // 
            // ToCitiDataDelete
            // 
            this.ToCitiDataDelete.FillWeight = 30F;
            this.ToCitiDataDelete.HeaderText = "Delete";
            this.ToCitiDataDelete.Name = "ToCitiDataDelete";
            this.ToCitiDataDelete.ReadOnly = true;
            this.ToCitiDataDelete.Text = "Exclude";
            this.ToCitiDataDelete.UseColumnTextForButtonValue = true;
            // 
            // ToCitiDataCombine
            // 
            this.ToCitiDataCombine.FillWeight = 30F;
            this.ToCitiDataCombine.HeaderText = "Combine";
            this.ToCitiDataCombine.Name = "ToCitiDataCombine";
            this.ToCitiDataCombine.ReadOnly = true;
            // 
            // toCitiDataBindingSource
            // 
            this.toCitiDataBindingSource.DataSource = typeof(eDDA.ToCitiData);
            // 
            // tabPageToCitiStep3
            // 
            this.tabPageToCitiStep3.Controls.Add(this.tableLayoutPanel11);
            this.tabPageToCitiStep3.Location = new System.Drawing.Point(124, 4);
            this.tabPageToCitiStep3.Name = "tabPageToCitiStep3";
            this.tabPageToCitiStep3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageToCitiStep3.Size = new System.Drawing.Size(1050, 618);
            this.tabPageToCitiStep3.TabIndex = 4;
            this.tabPageToCitiStep3.Text = "03. Convert";
            this.tabPageToCitiStep3.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 4;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 400F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 239F));
            this.tableLayoutPanel11.Controls.Add(this.label50, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.btnConvert, 1, 0);
            this.tableLayoutPanel11.Controls.Add(this.label51, 2, 0);
            this.tableLayoutPanel11.Controls.Add(this.label52, 2, 1);
            this.tableLayoutPanel11.Controls.Add(this.label53, 0, 3);
            this.tableLayoutPanel11.Controls.Add(this.btnGenerate, 1, 3);
            this.tableLayoutPanel11.Controls.Add(this.label54, 2, 3);
            this.tableLayoutPanel11.Controls.Add(this.label55, 2, 4);
            this.tableLayoutPanel11.Controls.Add(this.btnToCitiStep3Back, 0, 6);
            this.tableLayoutPanel11.Location = new System.Drawing.Point(32, 23);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 7;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(859, 382);
            this.tableLayoutPanel11.TabIndex = 8;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label50.Location = new System.Drawing.Point(3, 6);
            this.label50.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(85, 15);
            this.label50.TabIndex = 0;
            this.label50.Text = "TXT To XML";
            // 
            // btnConvert
            // 
            this.btnConvert.BackColor = System.Drawing.SystemColors.Control;
            this.btnConvert.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnConvert.Location = new System.Drawing.Point(123, 3);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(85, 34);
            this.btnConvert.TabIndex = 1;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = false;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(223, 6);
            this.label51.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(92, 17);
            this.label51.TabIndex = 2;
            this.label51.Text = "Folder Path";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(223, 46);
            this.label52.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(345, 34);
            this.label52.TabIndex = 3;
            this.label52.Text = "J:\\Treasury\\Account Receivable\\DDCitidirect – Merge\\";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label53.Location = new System.Drawing.Point(3, 126);
            this.label53.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(80, 30);
            this.label53.TabIndex = 4;
            this.label53.Text = "DDA Setup Report";
            // 
            // btnGenerate
            // 
            this.btnGenerate.BackColor = System.Drawing.SystemColors.Control;
            this.btnGenerate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnGenerate.Location = new System.Drawing.Point(123, 123);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(85, 34);
            this.btnGenerate.TabIndex = 5;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = false;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(223, 126);
            this.label54.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(72, 17);
            this.label54.TabIndex = 6;
            this.label54.Text = "File Path";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(223, 166);
            this.label55.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(87, 17);
            this.label55.TabIndex = 7;
            this.label55.Text = "U:\\???.xlsx";
            // 
            // btnToCitiStep3Back
            // 
            this.btnToCitiStep3Back.BackColor = System.Drawing.Color.SteelBlue;
            this.btnToCitiStep3Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnToCitiStep3Back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnToCitiStep3Back.Location = new System.Drawing.Point(3, 303);
            this.btnToCitiStep3Back.Name = "btnToCitiStep3Back";
            this.btnToCitiStep3Back.Size = new System.Drawing.Size(85, 34);
            this.btnToCitiStep3Back.TabIndex = 8;
            this.btnToCitiStep3Back.Text = "<< BACK";
            this.btnToCitiStep3Back.UseVisualStyleBackColor = false;
            this.btnToCitiStep3Back.Click += new System.EventHandler(this.btnToCitiStep3Back_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1192, 807);
            this.Controls.Add(this.tabControlMain);
            this.Controls.Add(this.statusStrip1);
            this.MinimumSize = new System.Drawing.Size(1100, 834);
            this.Name = "MainForm";
            this.Text = "eDDA";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tabControlMain.ResumeLayout(false);
            this.tabPageConfig.ResumeLayout(false);
            this.tabControlConfig.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tabPageFromCiti.ResumeLayout(false);
            this.tabControlFromCiti.ResumeLayout(false);
            this.tabPageFromCitiStep1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFrmCitiFileList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileListBindingSource)).EndInit();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPageFromCitiStep2.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tabPageToCiti.ResumeLayout(false);
            this.tabControlToCiti.ResumeLayout(false);
            this.tabPageToCitiStep1.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewToCitiFileList)).EndInit();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabPageToCitiStep2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewToCitiData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.toCitiDataBindingSource)).EndInit();
            this.tabPageToCitiStep3.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripLblUser;
        private System.Windows.Forms.TabControl tabControlMain;
        private System.Windows.Forms.TabPage tabPageConfig;
        private System.Windows.Forms.TabPage tabPageFromCiti;
        private System.Windows.Forms.TabPage tabPageToCiti;
        private System.Windows.Forms.TabControl tabControlConfig;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDDPInputPiys;
        private System.Windows.Forms.Label lblCfDDPInputPisysFile;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDDPInputHiTrust;
        private System.Windows.Forms.Label lblCfDDPInputHitrustFile;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDDPInputESPP;
        private System.Windows.Forms.Label lblCfDDPInputEsppFile;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDDPInputXML;
        private System.Windows.Forms.Label lblCfDDPInputXmlFile;
        private System.Windows.Forms.Button btnDDPInputSave;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDDPOutputPiys;
        private System.Windows.Forms.Label lblCfDDPOutputPisysFile;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtDDPOutputHiTrust;
        private System.Windows.Forms.Label lblCfDDPOutputHitrustFile;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtDDPOutputESPP;
        private System.Windows.Forms.Label lblCfDDPOutputEsppFile;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtDDPOutputXML;
        private System.Windows.Forms.Label lblCfDDPOutputXmlFile;
        private System.Windows.Forms.Button btnDDPOutputSave;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblCfDDAInputPisysFile;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtDDAInputHiTrust;
        private System.Windows.Forms.Label lblCfDDAInputHitrustFile;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtDDAInputESPP;
        private System.Windows.Forms.Label lblCfDDAInputEsppFile;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtDDAInputXML;
        private System.Windows.Forms.Label lblCfDDAInputXmlFile;
        private System.Windows.Forms.Button btnDDAInputSave;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtDDAOutputPiys;
        private System.Windows.Forms.Label lblCfDDAOutputPisysFile;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtDDAOutputHiTrust;
        private System.Windows.Forms.Label lblCfDDAOutputHitrustFile;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtDDAOutputESPP;
        private System.Windows.Forms.Label lblCfDDAOutputEsppFile;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtDDAOutputXML;
        private System.Windows.Forms.Label lblCfDDAOutputXmlFile;
        private System.Windows.Forms.Button btnDDAOutputSave;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label lblCfDDPRejRpt;
        private System.Windows.Forms.Button btnDDPRptSave;
        private System.Windows.Forms.TabControl tabControlFromCiti;
        private System.Windows.Forms.TabPage tabPageFromCitiStep1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.DateTimePicker dateFromCitiFromDt;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioBtnDDPFromCiti;
        private System.Windows.Forms.RadioButton radioBtnDDAFromCiti;
        private System.Windows.Forms.Button btnImportXml;
        private System.Windows.Forms.Button btnFromCitiStep1Next;
        private System.Windows.Forms.DataGridView dataGridViewFrmCitiFileList;
        private System.Windows.Forms.BindingSource fileListBindingSource;
        private System.Windows.Forms.TabPage tabPageFromCitiStep2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button btnFromCitiConvertTxt;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button btnFromCitiGenRpt;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Button btnFromCitiSendeMail;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Button btnFromCitiStep2Back;
        private System.Windows.Forms.TabControl tabControlToCiti;
        private System.Windows.Forms.TabPage tabPageToCitiStep1;
        private System.Windows.Forms.TabPage tabPageToCitiStep2;
        private System.Windows.Forms.TabPage tabPageToCitiStep3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.DateTimePicker dateToCitiFromDt;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton radioBtnDDPToCiti;
        private System.Windows.Forms.RadioButton radioBtnDDAToCiti;
        private System.Windows.Forms.Button buttonImport;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.DataGridView dataGridViewToCitiFileList;
        private System.Windows.Forms.Button btnToCitiStep1Next;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Label labelValidateMsg;
        private System.Windows.Forms.TextBox textBoxValidateMsg;
        private System.Windows.Forms.DataGridView dataGridViewToCitiData;
        private System.Windows.Forms.BindingSource toCitiDataBindingSource;
        private System.Windows.Forms.Button btnToCitiStep2Back;
        private System.Windows.Forms.Button btnToCitiStep2Next;
        private System.Windows.Forms.Button buttonCombine;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Button btnToCitiStep3Back;
        private System.Windows.Forms.DataGridViewTextBoxColumn fileNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn filePathDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn FromCitiDeleteFile;
        private System.Windows.Forms.Button btnResetFromCiti;
        private System.Windows.Forms.Button btnResetToCiti;
        private System.Windows.Forms.TextBox txtDDAInputPiys;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.DateTimePicker dateToCitiToDt;
        private System.Windows.Forms.DataGridViewTextBoxColumn recordID;
        private System.Windows.Forms.DataGridViewTextBoxColumn fileNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientReferenceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn payAmountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn payerNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valueDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn ToCitiDataEdit;
        private System.Windows.Forms.DataGridViewButtonColumn ToCitiDataDelete;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ToCitiDataCombine;
        private System.Windows.Forms.Label lblToDateFromCiti;
        private System.Windows.Forms.DateTimePicker dateFromCitiToDt;
        private System.Windows.Forms.Label lblCfDDPRejRptEmail;
        private System.Windows.Forms.Label lblCfDDPRejRptHm;
        private System.Windows.Forms.Label lblCfDDPRejRptEmailHm;
        private System.Windows.Forms.TextBox txtCfDDPRejRptEmailHm;
        private System.Windows.Forms.TextBox txtCfDDPRejRptHm;
        private System.Windows.Forms.TextBox txtCfDDPRejRptEmail;
        private System.Windows.Forms.TextBox txtCFDDPRejRpt;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TextBox txtClientCodePisysCobrd;
        private System.Windows.Forms.Button btnCfSaveDDASetup;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtClientCodePisysCore;
        private System.Windows.Forms.TextBox txtClientCodeHitrust;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtCFDDPSbmRpt;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtClientCodeESPP;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewButtonColumn toCitiFileDelete;
    }
}

