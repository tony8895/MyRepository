﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;


namespace eDDA
{
    public partial class MainForm : Form
    {
        DataTable fromCitiFileListTable = new DataTable();
        DataTable toCitiFileListTable = new DataTable();
        DataTable toCitiDataTable = new DataTable();

        public MainForm()
        {
            InitializeComponent();
            InitData();
        }
        private void MainForm_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            toolStripLblUser.Text = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            labelValidateMsg.Hide();
            textBoxValidateMsg.Hide();

            tabPageFromCitiStep1.Enabled = true;
            tabPageFromCitiStep2.Enabled = false;

            tabPageToCitiStep1.Enabled = true;
            tabPageToCitiStep2.Enabled = false;
            tabPageToCitiStep3.Enabled = false;

            preFillTabConfig();
        }

        #region InitTabControl
        private void InitData()
        {
            fromCitiFileListTable.Columns.Add("fileName", typeof(string));
            fromCitiFileListTable.Columns.Add("filePath", typeof(string));
            fromCitiFileListTable.Columns.Add("priority", typeof(int));
            dataGridViewFrmCitiFileList.DataSource = fromCitiFileListTable;

            toCitiFileListTable.Columns.Add("fileName", typeof(string));
            toCitiFileListTable.Columns.Add("filePath", typeof(string));
            toCitiFileListTable.Columns.Add("priority", typeof(int));
            dataGridViewToCitiFileList.DataSource = toCitiFileListTable;

            toCitiDataTable.Columns.Add("recordID", typeof(string));
            toCitiDataTable.Columns.Add("fileName", typeof(string));
            toCitiDataTable.Columns.Add("amount", typeof(string));
            toCitiDataTable.Columns.Add("clientCode", typeof(string));
            toCitiDataTable.Columns.Add("clientReference", typeof(string));
            toCitiDataTable.Columns.Add("payAmount", typeof(string));
            toCitiDataTable.Columns.Add("payerName", typeof(string));
            toCitiDataTable.Columns.Add("valueDate", typeof(string));
            toCitiDataTable.Columns.Add("index", typeof(int));
            toCitiDataTable.Columns.Add("grpNo", typeof(int));
            dataGridViewToCitiData.DataSource = toCitiDataTable;
        }

        private void tabControlConfig_DrawItem(object sender, DrawItemEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush _textBrush;

            // Get the item from the collection.
            TabPage _tabPage = tabControlConfig.TabPages[e.Index];

            // Get the real bounds for the tab rectangle.
            Rectangle _tabBounds = tabControlConfig.GetTabRect(e.Index);

            if (e.State == DrawItemState.Selected)
            {

                // Draw a different background color, and don't paint a focus rectangle.
                _textBrush = new SolidBrush(Color.Blue);
                g.FillRectangle(Brushes.Gray, e.Bounds);
            }
            else
            {
                _textBrush = new System.Drawing.SolidBrush(e.ForeColor);
                g.FillRectangle(Brushes.LightGray, e.Bounds);
                //e.DrawBackground();
            }

            // Use our own font.
            Font _tabFont = new Font("Arial", 10.0f, FontStyle.Bold, GraphicsUnit.Pixel);

            // Draw string. Center the text.
            StringFormat _stringFlags = new StringFormat();
            _stringFlags.Alignment = StringAlignment.Center;
            _stringFlags.LineAlignment = StringAlignment.Center;
            g.DrawString(_tabPage.Text, _tabFont, _textBrush, _tabBounds, new StringFormat(_stringFlags));
        }

        private void tabControlFromCiti_DrawItem(object sender, DrawItemEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush _textBrush;

            // Get the item from the collection.
            TabPage _tabPage = tabControlFromCiti.TabPages[e.Index];

            // Get the real bounds for the tab rectangle.
            Rectangle _tabBounds = tabControlFromCiti.GetTabRect(e.Index);

            if (e.State == DrawItemState.Selected)
            {

                // Draw a different background color, and don't paint a focus rectangle.
                _textBrush = new SolidBrush(Color.Blue);
                g.FillRectangle(Brushes.Gray, e.Bounds);
            }
            else
            {
                _textBrush = new System.Drawing.SolidBrush(e.ForeColor);
                g.FillRectangle(Brushes.LightGray, e.Bounds);
                //e.DrawBackground();
            }

            // Use our own font.
            Font _tabFont = new Font("Arial", 10.0f, FontStyle.Bold, GraphicsUnit.Pixel);

            // Draw string. Center the text.
            StringFormat _stringFlags = new StringFormat();
            _stringFlags.Alignment = StringAlignment.Center;
            _stringFlags.LineAlignment = StringAlignment.Center;
            g.DrawString(_tabPage.Text, _tabFont, _textBrush, _tabBounds, new StringFormat(_stringFlags));
        }

        private void tabControlToCiti_DrawItem(object sender, DrawItemEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush _textBrush;

            // Get the item from the collection.
            TabPage _tabPage = tabControlToCiti.TabPages[e.Index];

            // Get the real bounds for the tab rectangle.
            Rectangle _tabBounds = tabControlToCiti.GetTabRect(e.Index);

            if (e.State == DrawItemState.Selected)
            {

                // Draw a different background color, and don't paint a focus rectangle.
                _textBrush = new SolidBrush(Color.Blue);
                g.FillRectangle(Brushes.Gray, e.Bounds);
            }
            else
            {
                _textBrush = new System.Drawing.SolidBrush(e.ForeColor);
                g.FillRectangle(Brushes.LightGray, e.Bounds);
                //e.DrawBackground();
            }

            // Use our own font.
            Font _tabFont = new Font("Arial", 10.0f, FontStyle.Bold, GraphicsUnit.Pixel);

            // Draw string. Center the text.
            StringFormat _stringFlags = new StringFormat();
            _stringFlags.Alignment = StringAlignment.Center;
            _stringFlags.LineAlignment = StringAlignment.Center;
            g.DrawString(_tabPage.Text, _tabFont, _textBrush, _tabBounds, new StringFormat(_stringFlags));
        }

        private void tabControlFromCiti_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (!e.TabPage.Enabled)
            {
                e.Cancel = true;
            }
        }

        private void tabControlToCiti_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (!e.TabPage.Enabled)
            {
                e.Cancel = true;
            }
        }
        #endregion

        #region Config
        private void preFillTabConfig()
        {
            //DDP Input
            txtDDPInputPiys.Text = ConfigurationManager.AppSettings.Get("DDP_Input_Pisys");
            lblCfDDPInputPisysFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDP_Input_Pisys_Files") + "]";
            txtDDPInputHiTrust.Text = ConfigurationManager.AppSettings.Get("DDP_Input_HiTrust");
            lblCfDDPInputHitrustFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDP_Input_Hitrust_Files") + "]";
            txtDDPInputESPP.Text = ConfigurationManager.AppSettings.Get("DDP_Input_ESPP");
            lblCfDDPInputEsppFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDP_Input_ESPP_Files") + "]";
            txtDDPInputXML.Text = ConfigurationManager.AppSettings.Get("DDP_Input_XML");
            lblCfDDPInputXmlFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDP_Input_XML_Files") + "]";

            //DDP Output
            txtDDPOutputPiys.Text = ConfigurationManager.AppSettings.Get("DDP_Output_Pisys");
            lblCfDDPOutputPisysFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDP_Output_Pisys_Files") + "]";
            txtDDPOutputHiTrust.Text = ConfigurationManager.AppSettings.Get("DDP_Output_HiTrust");
            lblCfDDPOutputHitrustFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDP_Output_HiTrust_Files") + "]";
            txtDDPOutputESPP.Text = ConfigurationManager.AppSettings.Get("DDP_Output_ESPP");
            lblCfDDPOutputEsppFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDP_Output_ESPP_Files") + "]";
            txtDDPOutputXML.Text = ConfigurationManager.AppSettings.Get("DDP_Output_XML");
            lblCfDDPOutputXmlFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDP_Output_XML_Files") + "]";

            //DDA Input
            txtDDAInputPiys.Text = ConfigurationManager.AppSettings.Get("DDA_Input_Pisys");
            lblCfDDAInputPisysFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDA_Input_Pisys_Files") + "]";
            txtDDAInputHiTrust.Text = ConfigurationManager.AppSettings.Get("DDA_Input_HiTrust");
            lblCfDDAInputHitrustFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDA_Input_HiTrust_Files") + "]";
            txtDDAInputESPP.Text = ConfigurationManager.AppSettings.Get("DDA_Input_ESPP");
            lblCfDDAInputEsppFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDA_Input_ESPP_Files") + "]";
            txtDDAInputXML.Text = ConfigurationManager.AppSettings.Get("DDA_Input_XML");
            lblCfDDAInputXmlFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDA_Input_XML_Files") + "]";

            //DDA Output
            txtDDAOutputPiys.Text = ConfigurationManager.AppSettings.Get("DDA_Output_Pisys");
            lblCfDDAOutputPisysFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDA_Output_Pisys_Files") + "]";
            txtDDAOutputHiTrust.Text = ConfigurationManager.AppSettings.Get("DDA_Output_HiTrust");
            lblCfDDAOutputHitrustFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDA_Output_HiTrust_Files") + "]";
            txtDDAOutputESPP.Text = ConfigurationManager.AppSettings.Get("DDA_Output_ESPP");
            lblCfDDAOutputEsppFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDA_Output_ESPP_Files") + "]";
            txtDDAOutputXML.Text = ConfigurationManager.AppSettings.Get("DDA_Output_XML");
            lblCfDDAOutputXmlFile.Text = "[" + ConfigurationManager.AppSettings.Get("DDA_Output_XML_Files") + "]";

            //DDP Report
            txtCFDDPSbmRpt.Text = ConfigurationManager.AppSettings.Get("DDP_Submission_Rpt_Folder");
            txtCFDDPRejRpt.Text = ConfigurationManager.AppSettings.Get("DDP_Reject_Rpt_Folder");
            txtCfDDPRejRptEmail.Text = ConfigurationManager.AppSettings.Get("DDP_Reject_Rpt_Emails");
            txtCfDDPRejRptHm.Text = ConfigurationManager.AppSettings.Get("DDP_Reject_Rpt_Folder_Home");
            txtCfDDPRejRptEmailHm.Text = ConfigurationManager.AppSettings.Get("DDP_Reject_Rpt_Emails_Home");

            //Others
            txtClientCodePisysCobrd.Text = ConfigurationManager.AppSettings.Get("Map_Clnt_Code_Pisys_cobrand");
            txtClientCodePisysCore.Text = ConfigurationManager.AppSettings.Get("Map_Clnt_Code_Pisys_core");
            txtClientCodeHitrust.Text = ConfigurationManager.AppSettings.Get("Map_Clnt_Code_Hitrust");
            txtClientCodeESPP.Text = ConfigurationManager.AppSettings.Get("Map_Clnt_Code_ESPP");
        }

        private void btnDDPInputSave_Click(object sender, EventArgs e)
        {
            var configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            var settings = configFile.AppSettings.Settings;

            settings["DDP_Input_Pisys"].Value = txtDDPInputPiys.Text.Trim();
            settings["DDP_Input_HiTrust"].Value = txtDDPInputHiTrust.Text.Trim();
            settings["DDP_Input_ESPP"].Value = txtDDPInputESPP.Text.Trim();
            settings["DDP_Input_XML"].Value = txtDDPInputXML.Text.Trim();

            configFile.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name);
            MessageBox.Show("Config is saved!");
        }

        private void btnDDPOutputSave_Click(object sender, EventArgs e)
        {
            var configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            var settings = configFile.AppSettings.Settings;

            settings["DDP_Output_Pisys"].Value = txtDDPOutputPiys.Text.Trim();
            settings["DDP_Output_HiTrust"].Value = txtDDPOutputHiTrust.Text.Trim();
            settings["DDP_Output_ESPP"].Value = txtDDPOutputESPP.Text.Trim();
            settings["DDP_Output_XML"].Value = txtDDPOutputXML.Text.Trim();

            configFile.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name);
            MessageBox.Show("Config is saved!");
        }

        private void btnDDAInputSave_Click(object sender, EventArgs e)
        {
            var configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            var settings = configFile.AppSettings.Settings;

            settings["DDA_Input_Pisys"].Value = txtDDAInputPiys.Text.Trim();
            settings["DDA_Input_HiTrust"].Value = txtDDAInputHiTrust.Text.Trim();
            settings["DDA_Input_ESPP"].Value = txtDDAInputESPP.Text.Trim();
            settings["DDA_Input_XML"].Value = txtDDAInputXML.Text.Trim();

            configFile.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name);
            MessageBox.Show("Config is saved!");
        }

        private void btnDDAOutputSave_Click(object sender, EventArgs e)
        {
            var configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            var settings = configFile.AppSettings.Settings;

            settings["DDA_Output_Pisys"].Value = txtDDAOutputPiys.Text.Trim();
            settings["DDA_Output_HiTrust"].Value = txtDDAOutputHiTrust.Text.Trim();
            settings["DDA_Output_ESPP"].Value = txtDDAOutputESPP.Text.Trim();
            settings["DDA_Output_XML"].Value = txtDDAOutputXML.Text.Trim();

            configFile.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name);
            MessageBox.Show("Config is saved!");
        }

        private void btnDDPRptSave_Click(object sender, EventArgs e)
        {
            var configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            var settings = configFile.AppSettings.Settings;

            settings["DDP_Submission_Rpt_Folder"].Value = txtCFDDPSbmRpt.Text.Trim();
            settings["DDP_Reject_Rpt_Folder"].Value = txtCFDDPRejRpt.Text.Trim();
            settings["DDP_Reject_Rpt_Emails"].Value = txtCfDDPRejRptEmail.Text.Trim();
            settings["DDP_Reject_Rpt_Folder_Home"].Value = txtCfDDPRejRptHm.Text.Trim();
            settings["DDP_Reject_Rpt_Emails_Home"].Value = txtCfDDPRejRptEmailHm.Text.Trim();

            configFile.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name);
            MessageBox.Show("Config is saved!");
        }

        private void btnCfSaveDDASetup_Click(object sender, EventArgs e)
        {
            var configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            var settings = configFile.AppSettings.Settings;

            settings["Map_Clnt_Code_Pisys_cobrand"].Value = txtClientCodePisysCobrd.Text.Trim();
            settings["Map_Clnt_Code_Pisys_core"].Value = txtClientCodePisysCore.Text.Trim();
            settings["Map_Clnt_Code_Hitrust"].Value = txtClientCodeHitrust.Text.Trim();
            settings["Map_Clnt_Code_ESPP"].Value = txtClientCodeESPP.Text.Trim();

            configFile.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name);
            MessageBox.Show("Config is saved!");
        }
        #endregion

        #region FromCiti_Step1
        private void radioBtnFromCiti_Click(object sender, EventArgs e)
        {
            if (btnImportXml.Enabled == false)
                btnImportXml.Enabled = true;
        }

        private void btnImportXml_Click(object sender, EventArgs e)
        {
            if (dateFromCitiToDt.Value.Date < dateFromCitiFromDt.Value.Date)
            {
                MessageBox.Show("To Date should be after From Date!");
                return;
            }

            string monthDay;
            DataTable tempTable = fromCitiFileListTable.Clone();
            DateTime currentDt = dateFromCitiFromDt.Value;

            fromCitiFileListTable.Clear();

            do
            {
                monthDay = currentDt.ToString("ddMMyyyy");

                if (radioBtnDDPFromCiti.Checked == true)
                {
                    loadInputFilesFromConfig("DDP_Input_Pisys", "DDP_Input_Pisys_Files", 1, monthDay, ref tempTable);
                    loadInputFilesFromConfig("DDP_Input_HiTrust", "DDP_Input_HiTrust_Files", 2, monthDay, ref tempTable);
                    loadInputFilesFromConfig("DDP_Input_ESPP", "DDP_Input_ESPP_Files", 3, monthDay, ref tempTable);
                }
                else if (radioBtnDDAFromCiti.Checked == true)
                {
                    loadInputFilesFromConfig("DDA_Input_Pisys", "DDA_Input_Pisys_Files", 1, monthDay, ref tempTable);
                    loadInputFilesFromConfig("DDA_Input_HiTrust", "DDA_Input_HiTrust_Files", 2, monthDay, ref tempTable);
                    loadInputFilesFromConfig("DDA_Input_ESPP", "DDA_Input_ESPP_Files", 3, monthDay, ref tempTable);
                }

                currentDt = currentDt.AddDays(1);

            } while (currentDt.Date <= dateFromCitiToDt.Value.Date);

            if (tempTable.Rows.Count == 0)
            {
                MessageBox.Show("No file is imported!");
                return;
            }

            DataView dv = new DataView(tempTable);
            dv.Sort = "priority ASC, fileName ASC";
            DataTable sortTable = dv.ToTable();
            fromCitiFileListTable.Clear();

            foreach (DataRow r in sortTable.Rows)
            {
                fromCitiFileListTable.Rows.Add(r.ItemArray);
            }
        }

        private void loadInputFilesFromConfig(string configFolder, string configFileList, int priority, string strDate, ref DataTable dt)
        {
            string[] files = ConfigurationManager.AppSettings.Get(configFileList).Split('/');

            foreach (string f in files)
            {
                string sourceFile = Path.Combine(ConfigurationManager.AppSettings.Get(configFolder), f.Replace("ddmmyyyy", strDate).Trim());
                string destFile = Path.GetDirectoryName(Application.ExecutablePath) + @"\process\" + f.Replace("ddmmyyyy", strDate).Trim();
                if (File.Exists(sourceFile))
                {

                    File.Copy(sourceFile, destFile, true);
                    dt.Rows.Add(f.Replace("ddmmyyyy", strDate), System.IO.Path.Combine(ConfigurationManager.AppSettings.Get(configFolder)), priority);
                }
            }
        }

        private void dataGridViewFrmCitiFileList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewFrmCitiFileList.Columns[e.ColumnIndex].Name == "FromCitiDeleteFile")
            {
                var Result = MessageBox.Show("Confirm to remove this file?", "Remove", MessageBoxButtons.YesNo);
                if (Result == DialogResult.Yes)
                {
                    dataGridViewFrmCitiFileList.Rows.RemoveAt(e.RowIndex);
                }
            }
        }

        private void btnFromCitiStep1Next_Click(object sender, EventArgs e)
        {

            //if (fromCitiFileListTable.Rows.Count == 0)
            //{
            //    MessageBox.Show("Pls import file!");
            //    return;
            //}

            tabPageFromCitiStep1.Enabled = false;
            tabPageFromCitiStep2.Enabled = true;
            tabControlFromCiti.SelectedIndex = 1;
        }
        #endregion

        #region FromCiti_Step2
        private void btnFromCitiStep2Back_Click(object sender, EventArgs e)
        {
            tabPageFromCitiStep1.Enabled = true;
            tabPageFromCitiStep2.Enabled = false;
            tabControlFromCiti.SelectedIndex = 0;
        }

        private void btnFromCitiConvertTxt_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Function is not ready!");
        }

        private void btnFromCitiGenRpt_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Function is not ready!");
        }

        private void btnFromCitiSendeMail_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Function is not ready!");
        }
        #endregion

        #region ToCiti_Step1
        private void radioBtnToCiti_Click(object sender, EventArgs e)
        {
            if (buttonImport.Enabled == false)
                buttonImport.Enabled = true;
        }

        private void buttonImport_Click(object sender, EventArgs e)
        {
            if (dateToCitiToDt.Value.Date < dateToCitiFromDt.Value.Date)
            {
                MessageBox.Show("To Date should be after From Date!");
                return;
            }

            string monthDay;
            DataTable tempTable = toCitiFileListTable.Clone();
            DateTime currentDt = dateToCitiFromDt.Value;

            toCitiFileListTable.Clear();

            do
            {
                monthDay = currentDt.ToString("yyyyMMdd").Substring(4, 4);

                if (radioBtnDDPToCiti.Checked == true)
                {
                    loadFilesFromConfig("DDP_Output_Pisys", "DDP_Output_Pisys_Files", 1, monthDay, ref tempTable);
                    loadFilesFromConfig("DDP_Output_HiTrust", "DDP_Output_HiTrust_Files", 2, monthDay, ref tempTable);
                    loadFilesFromConfig("DDP_Output_ESPP", "DDP_Output_ESPP_Files", 3, monthDay, ref tempTable);
                }
                else if (radioBtnDDAToCiti.Checked == true)
                {
                    loadFilesFromConfig("DDA_Output_Pisys", "DDA_Output_Pisys_Files", 1, monthDay, ref tempTable);
                    loadFilesFromConfig("DDA_Output_HiTrust", "DDA_Output_HiTrust_Files", 2, monthDay, ref tempTable);
                    loadFilesFromConfig("DDA_Output_ESPP", "DDA_Output_ESPP_Files", 3, monthDay, ref tempTable);
                }

                currentDt = currentDt.AddDays(1);

            } while (currentDt.Date <= dateToCitiToDt.Value.Date);

            if (tempTable.Rows.Count == 0)
            {
                MessageBox.Show("No file is imported!");
                return;
            }

            DataView dv = new DataView(tempTable);
            dv.Sort = "priority ASC, fileName ASC";
            DataTable sortTable = dv.ToTable();
            toCitiFileListTable.Clear();

            foreach (DataRow r in sortTable.Rows)
            {
                toCitiFileListTable.Rows.Add(r.ItemArray);
            }

        }

        private void btnToCitiStep1Next_Click(object sender, EventArgs e)
        {
            if (radioBtnDDAToCiti.Checked == true)
            {
                tabPageToCitiStep1.Enabled = false;
                tabPageToCitiStep2.Enabled = false;
                tabPageToCitiStep3.Enabled = true;
                tabControlToCiti.SelectedIndex = 2;
                return;
            }

            if (toCitiFileListTable.Rows.Count == 0)
            {
                MessageBox.Show("Pls import file!");
                return;
            }

            tabPageToCitiStep1.Enabled = false;
            tabPageToCitiStep2.Enabled = true;
            tabPageToCitiStep3.Enabled = false;
            tabControlToCiti.SelectedIndex = 1;

            toCitiDataTable.Clear();
            int i = 0;

            foreach (DataRow r in toCitiFileListTable.Rows)
            {
                var lines = File.ReadAllLines(Path.GetDirectoryName(Application.ExecutablePath) + @"\process\" + r[0].ToString());

                foreach (string line in lines)
                {
                    string[] columns = line.Split('*');
                    toCitiDataTable.Rows.Add(i + 1, r[0].ToString(), columns[0], columns[1], columns[2], columns[3], columns[4], columns[5], i, 0);
                    i++;
                }
            }

            doOrderToCitiData();
            doHighLightRows();
        }

        private void doOrderToCitiData()
        {
            int i = 0;

            var grpRows = from row in toCitiDataTable.AsEnumerable()
                          group row by new
                          {
                              clientCode = row.Field<string>("clientCode"),
                              clientReference = row.Field<string>("clientReference"),
                              payAmount = row.Field<string>("payAmount"),
                              payerName = row.Field<string>("payerName"),
                              valueDate = row.Field<string>("valueDate")
                          } into g
                          let glist = g.ToList()
                          select new
                          {
                              gKey = g.Key,
                              subList = glist,
                              count = glist.Count
                          };

            var rows = from grpRow in grpRows
                       where grpRow.count > 1
                       select grpRow;

            foreach (var row in rows)
            {
                i++;

                foreach (var item in row.subList)
                {
                    int j = item.Field<int>("index");
                    toCitiDataTable.Rows[j][9] = i;
                }
            }

            if (i == 0)
                return;

            DataView dv = new DataView(toCitiDataTable);
            dv.Sort = "grpNo DESC, index ASC";
            DataTable tableTemp = dv.ToTable();
            toCitiDataTable.Clear();
            int k = 0;

            foreach (DataRow r in tableTemp.Rows)
            {
                toCitiDataTable.Rows.Add(r.ItemArray);
                toCitiDataTable.Rows[k][8] = k;
                toCitiDataTable.Rows[k][0] = k + 1;
                k++;
            }
        }

        private void doHighLightRows()
        {
            foreach (DataRow r in toCitiDataTable.Rows)
            {
                if (r.Field<int>("grpNO") > 0)
                {
                    dataGridViewToCitiData.Rows[r.Field<int>("index")].DefaultCellStyle.BackColor = Color.Yellow;
                }
                else
                {
                    dataGridViewToCitiData.Rows[r.Field<int>("index")].DefaultCellStyle.BackColor = Color.Empty;
                }
            }
        }

        private void dataGridViewToCitiFileList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewToCitiFileList.Columns[e.ColumnIndex].Name == "toCitiFileDelete")
            {
                var Result = MessageBox.Show("Confirm to remove this file?", "Remove", MessageBoxButtons.YesNo);
                if (Result == DialogResult.Yes)
                {
                    toCitiFileListTable.Rows.RemoveAt(e.RowIndex);
                }
            }
        }
        #endregion

        #region ToCiti_Step2

        private void btnToCitiStep2Back_Click(object sender, EventArgs e)
        {
            tabPageToCitiStep1.Enabled = true;
            tabPageToCitiStep2.Enabled = false;
            tabPageToCitiStep3.Enabled = false;
            tabControlToCiti.SelectedIndex = 0;
        }

        private void btnToCitiStep2Next_Click(object sender, EventArgs e)
        {
            if (dataGridViewToCitiData.Rows.Count == 0)
            {
                MessageBox.Show("Pls load data!");
                return;
            }

            tabPageToCitiStep1.Enabled = false;
            tabPageToCitiStep2.Enabled = false;
            tabPageToCitiStep3.Enabled = true;
            tabControlToCiti.SelectedIndex = 2;
        }

        private void loadFilesFromConfig(string configFolder, string configFileList, int priority, string mmdd, ref DataTable dt)
        {
            string[] files = ConfigurationManager.AppSettings.Get(configFileList).Split('/');

            foreach (string f in files)
            {
                string sourceFile = Path.Combine(ConfigurationManager.AppSettings.Get(configFolder), f.Replace("mmdd", mmdd).Trim());
                string destFile = Path.GetDirectoryName(Application.ExecutablePath) + @"\process\" + f.Replace("mmdd", mmdd).Trim();
                if (File.Exists(sourceFile))
                {
                        
                    File.Copy(sourceFile, destFile, true);
                    dt.Rows.Add(f.Replace("mmdd", mmdd), System.IO.Path.Combine(ConfigurationManager.AppSettings.Get(configFolder)), priority);
                }
            }
        }

        private void dataGridViewToCitiData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            if (dataGridViewToCitiData.Columns[e.ColumnIndex].Name == "ToCitiDataDelete")
            {
                var Result = MessageBox.Show("Confirm to exclude this row?", "Exclude", MessageBoxButtons.YesNo);
                if (Result == DialogResult.Yes)
                {
                    dataGridViewToCitiData.Rows.RemoveAt(e.RowIndex);
                }
            }

            if (dataGridViewToCitiData.Columns[e.ColumnIndex].Name == "ToCitiDataEdit")
            {
                ToCitiData toCitiData = new ToCitiData()
                {
                    index = e.RowIndex,
                    fileName = dataGridViewToCitiData.Rows[e.RowIndex].Cells[1].Value.ToString(),
                    amount = dataGridViewToCitiData.Rows[e.RowIndex].Cells[2].Value.ToString(),
                    clientCode = dataGridViewToCitiData.Rows[e.RowIndex].Cells[3].Value.ToString(),
                    clientReference = dataGridViewToCitiData.Rows[e.RowIndex].Cells[4].Value.ToString(),
                    payAmount = dataGridViewToCitiData.Rows[e.RowIndex].Cells[5].Value.ToString(),
                    payerName = dataGridViewToCitiData.Rows[e.RowIndex].Cells[6].Value.ToString(),
                    valueDate = dataGridViewToCitiData.Rows[e.RowIndex].Cells[7].Value.ToString()
                };

                EditRecordForm inputDDAForm = new EditRecordForm(toCitiData);
                inputDDAForm.EditFmSubmitted += editDataGridRow;
                inputDDAForm.ShowDialog();               
            }

            if (dataGridViewToCitiData.Columns[e.ColumnIndex].Name == "ToCitiDataCombine")
            {
                if (dataGridViewToCitiData.Rows[e.RowIndex].Cells[10].Value == null)
                    dataGridViewToCitiData.Rows[e.RowIndex].Cells[10].Value = false;

                dataGridViewToCitiData.Rows[e.RowIndex].Cells[10].Value = !Boolean.Parse(dataGridViewToCitiData.Rows[e.RowIndex].Cells[10].Value.ToString());
            }
        }

        private void editDataGridRow(object sender, ToCitiData e)
        {
            dataGridViewToCitiData.Rows[e.index].Cells[2].Value = e.amount;
            dataGridViewToCitiData.Rows[e.index].Cells[7].Value = e.valueDate;
        }

        private void buttonCombine_Click(object sender, EventArgs e)
        {

            doCombineRecords();

            for (int i = 0; i < dataGridViewToCitiData.RowCount; i++)
            {
                if (dataGridViewToCitiData.Rows[i].Cells[10].Value == null ? false: Boolean.Parse(dataGridViewToCitiData.Rows[i].Cells[10].Value.ToString()) == true)
                {
                    dataGridViewToCitiData.Rows[i].Cells[10].Value = false;
                }
            }

        }

        private void doCombineRecords()
        {
            DataTable selectTable = toCitiDataTable.Clone();
            DataTable unselectTable = toCitiDataTable.Clone();
            DataTable sortTable = toCitiDataTable.Clone();

            foreach (DataGridViewRow r in dataGridViewToCitiData.Rows)
            {
                if (r.Cells["ToCitiDataCombine"].Value == null ? false : Boolean.Parse(r.Cells["ToCitiDataCombine"].Value.ToString()) == true)
                {
                    if (Int32.Parse(toCitiDataTable.Rows[r.Index][9].ToString()) > 0)
                        selectTable.ImportRow(toCitiDataTable.Rows[r.Index]);
                    else
                        unselectTable.ImportRow(toCitiDataTable.Rows[r.Index]);
                }
                else
                {
                    unselectTable.ImportRow(toCitiDataTable.Rows[r.Index]);
                }
            }

            if (selectTable.Rows.Count == 0)
                return;

            var combinerows = from row in selectTable.AsEnumerable()
                              group row by row.Field<int>("grpNo") into g
                              orderby g.Key descending
                              select g;

            double amount;
            int j = 0;
            int maxRecordID = Int32.Parse(toCitiDataTable.AsEnumerable().Max(row => Int32.Parse(row["recordID"].ToString())).ToString());

            foreach (var combinerow in combinerows)
            {
                amount = 0;
                maxRecordID++;

                foreach (var row in combinerow.ToList())
                {
                    amount = amount + double.Parse(row.Field<string>("amount"));
                }

                sortTable.ImportRow(combinerow.ToList().First());
                sortTable.Rows[j][0] = maxRecordID;
                sortTable.Rows[j][1] = "Combined";
                sortTable.Rows[j][2] = amount.ToString();
                j++;
            }

            j = 0;
            toCitiDataTable.Clear();

            foreach (DataRow r in sortTable.Rows)
            {
                toCitiDataTable.Rows.Add(r.ItemArray);
                toCitiDataTable.Rows[j][8] = j;
                j++;
            }

            foreach (DataRow r in unselectTable.Rows)
            {
                toCitiDataTable.Rows.Add(r.ItemArray);
                toCitiDataTable.Rows[j][8] = j;
                j++;
            }
        }
        #endregion

        #region ToCiti_Step3
        private void btnConvert_Click(object sender, EventArgs e)
        {
            MessageBox.Show("XML is generated!");
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            if (radioBtnDDAToCiti.Checked == true)
            {
                MessageBox.Show("It's only for DDP");
                return;
            }

            Excel.Application oXL;
            Excel._Workbook oWB;
            Excel._Worksheet oSheet1;

            oXL = new Excel.Application();
            oXL.Visible = false;

            oWB = (Excel._Workbook)(oXL.Workbooks.Add(Missing.Value));
            oSheet1 = (Excel._Worksheet)oWB.Worksheets["Sheet1"];
            oSheet1.Name = "Pisys";

            genPisysDDPReport(ref oSheet1);
            oSheet1.Columns.AutoFit();

            oWB.SaveAs(@"C:\Users\T999117.PRINCIPALUSA\Desktop\eDDA\UT_DATA\test.xlsx");
            oWB.Close();
            oXL.Quit();
            MessageBox.Show("Report is generated!");

        }

        private void genPisysDDPReport(ref Excel._Worksheet oSheet)
        {
            int i = 6;
            int subCount;
            double subTotal;
            int totalCount = 0;
            double totalAmount = 0;
            string lastValueDate="";
            string configScheme="";
            string schemeName="";
            int startPos;
            int endPos;

            oSheet.Cells[1, 1] = "Pisys";
            oSheet.Cells[1, 1].EntireRow.Font.Bold = true;

            oSheet.Cells[3, 1] = "DDP Submission Report";
            oSheet.Cells[3, 1].EntireRow.Font.Bold = true;

            oSheet.Cells[4, 1] = "Generation date:";
            oSheet.Cells[6, 1] = "Value Date + 2 b.d.";
            oSheet.Cells[6, 2] = "Client Code";
            oSheet.Cells[6, 3] = "Scheme";
            oSheet.Cells[6, 4] = "Value Date";
            oSheet.Cells[6, 5] = "Amount";
            oSheet.Cells[6, 6] = "Count";
            oSheet.Cells[6, 1].EntireRow.Font.Bold = true;

            var grpPisys = from row in toCitiDataTable.AsEnumerable()
                           group row by new
                           {
                               clientCode = row.Field<string>("clientCode"),
                               valueDate = row.Field<string>("valueDate")
                           } into g
                           orderby g.Key.valueDate ascending
                           select g;

            foreach (var grp in grpPisys)
            {
                subCount = 0;
                subTotal = 0;

                foreach (var item in grp.ToList())
                {
                    subCount++;
                    subTotal = subTotal + double.Parse(item.Field<string>("amount"));
                }

                if (lastValueDate != "" && lastValueDate != grp.Key.valueDate)
                {
                    i = i+2;
                    oSheet.Cells[i, 2] = "Total";
                    oSheet.Cells[i, 4] = lastValueDate;
                    oSheet.Cells[i, 5] = totalAmount.ToString();
                    oSheet.Cells[i, 6] = totalCount.ToString();
                    totalAmount = 0;
                    totalCount = 0;
                    oSheet.Cells[i, 1].EntireRow.Font.Bold = true;
                    i++;
                }

                i++;
                oSheet.Cells[i, 2] = grp.Key.clientCode;

                if (ConfigurationManager.AppSettings.Get("Map_Clnt_Code_Pisys_cobrand").Contains(grp.Key.clientCode))
                {
                    configScheme = ConfigurationManager.AppSettings.Get("Map_Clnt_Code_Pisys_cobrand");
                }
                else if (ConfigurationManager.AppSettings.Get("Map_Clnt_Code_Pisys_core").Contains(grp.Key.clientCode))
                {
                    configScheme = ConfigurationManager.AppSettings.Get("Map_Clnt_Code_Pisys_core");
                }
                else if (ConfigurationManager.AppSettings.Get("Map_Clnt_Code_Hitrust").Contains(grp.Key.clientCode))
                {
                    configScheme = ConfigurationManager.AppSettings.Get("Map_Clnt_Code_Hitrust");
                }
                else if (ConfigurationManager.AppSettings.Get("Map_Clnt_Code_ESPP").Contains(grp.Key.clientCode))
                {
                    configScheme = ConfigurationManager.AppSettings.Get("Map_Clnt_Code_ESPP");
                }

                startPos = configScheme.IndexOf(grp.Key.clientCode) + grp.Key.clientCode.Length + 1;
                endPos = configScheme.IndexOf(";", configScheme.IndexOf(grp.Key.clientCode));

                if (endPos < 0)
                {
                    schemeName = configScheme.Substring(startPos);
                }
                else
                {
                    schemeName = configScheme.Substring(startPos, endPos - configScheme.IndexOf(grp.Key.clientCode) - grp.Key.clientCode.Length - 1);
                }

                oSheet.Cells[i, 3] = schemeName;
                oSheet.Cells[i, 4] = grp.Key.valueDate;
                oSheet.Cells[i, 5] = subTotal.ToString();
                oSheet.Cells[i, 6] = subCount.ToString();
                totalAmount = totalAmount + subTotal;
                totalCount = totalCount + subCount;
                lastValueDate = grp.Key.valueDate;
            }

            i = i+2;
            oSheet.Cells[i, 2] = "Total";
            oSheet.Cells[i, 4] = lastValueDate;
            oSheet.Cells[i, 5] = totalAmount.ToString();
            oSheet.Cells[i, 6] = totalCount.ToString();
            oSheet.Cells[i, 1].EntireRow.Font.Bold = true;

            oSheet.Columns[2].NumberFormat = "@";
        }

        private void btnToCitiStep3Back_Click(object sender, EventArgs e)
        {
            if (radioBtnDDAToCiti.Checked == true)
            {
                tabPageToCitiStep1.Enabled = true;
                tabPageToCitiStep2.Enabled = false;
                tabPageToCitiStep3.Enabled = false;
                tabControlToCiti.SelectedIndex = 0;
            }
            else
            {
                tabPageToCitiStep1.Enabled = false;
                tabPageToCitiStep2.Enabled = true;
                tabPageToCitiStep3.Enabled = false;
                tabControlToCiti.SelectedIndex = 1;
            }
        }
        #endregion

        #region Reset
        private void btnResetToCiti_Click(object sender, EventArgs e)
        {
            toCitiFileListTable.Clear();
            toCitiDataTable.Clear();
            tabPageToCitiStep1.Enabled = true;
            tabPageToCitiStep2.Enabled = false;
            tabPageToCitiStep3.Enabled = false;
            tabControlToCiti.SelectedIndex = 0;

            radioBtnDDAToCiti.Checked = false;
            radioBtnDDPToCiti.Checked = false;
            buttonImport.Enabled = false;

        }

        private void btnResetFromCiti_Click(object sender, EventArgs e)
        {
            fromCitiFileListTable.Clear();
            tabPageFromCitiStep1.Enabled = true;
            tabPageFromCitiStep2.Enabled = false;
            tabControlFromCiti.SelectedIndex = 0;

            radioBtnDDAFromCiti.Checked = false;
            radioBtnDDPFromCiti.Checked = false;
            btnImportXml.Enabled = false;
        }
        #endregion
    }
}
